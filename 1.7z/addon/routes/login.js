import Ember from 'ember';
import UnauthenticatedRouteMixin from 'ember-simple-auth/mixins/unauthenticated-route-mixin';

export default Ember.Route.extend(UnauthenticatedRouteMixin, {
  authenticator: 'service:coreAuthentication',

  setupController: function (controller) {
    controller.set('name', controller.namespace.get('name'));
  },
  renderTemplate() {
    this.render('login', {
      outlet: 'login-placeholder'
    });
  },

  actions: {
    authenticate(callback) {
      //called authenticate on session as older method has been depricated.
      var promise = this.get('session').authenticate(this.authenticator, {
        identification: Ember.$('.user-name').val(),
        password: Ember.$('.password').val()
      }).catch((reason) => {
        this.controller.set('errorMessage', (reason.error || reason));
      });

      //Commented this as this way of authentication is depricated.
      //var promise = this._super.apply(this, arguments);
      callback(promise);

      return promise;
    }
  }
});
