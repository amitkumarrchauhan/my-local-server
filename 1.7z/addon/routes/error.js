import Ember from 'ember';

export default Ember.Route.extend({
    model: function (params) {
      console.log('ui-base application route called: model hook');

      var subRoute = params.bad,
      moduleName = this.moduleLoader._getModuleName(subRoute.split('/')[0]),
        self = this, moduleLoader = this.moduleLoader;

      if (moduleLoader.isModuleLoaded(moduleName) !== true) {
        return moduleLoader.loadModule(moduleName).then(function () {
          self.router.handleURL(subRoute);
        });
      } else {
        self.router.handleURL(subRoute);
      }
    }
});
