import AuthenticatedApplicationRoute from 'supdash-ui-core/routes/authenticated-application';
import { MousetrapRoute, mousetrap } from 'ember-mousetrap';

export default AuthenticatedApplicationRoute.extend(MousetrapRoute, {

  shortcuts: {
    onEscape: mousetrap(['esc'], function () {
      this.flyoutManager.closeOnEscape();
      this.dialogManager.closeOnEscape();
    })
  },

  getAppName () {
    //Using regex to strip html tags from the title
    return this.controller.namespace.name.replace(/<\/?[^>]+(>|$)/g, "");
  },

  title: function (tokens) {
    var base = this.getAppName(), hasTokens = tokens && tokens.length;
    return hasTokens ? tokens.pop() + ' - ' + base : base;
  },

  actions: {
    showUserProfile () {
      /*Do nothing- Default implmnt. for showUserProfile
      addon apps should override for any specific implmnt.*/
    },
    showUserProfileClick () {
      /*Do nothing- Default implmnt. for showUserProfile
      addon apps should override for any specific implmnt.*/
    }
  }
});
