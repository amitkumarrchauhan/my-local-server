import Ember from 'ember';

export default Ember.Mixin.create({
    init() {
        Ember.assert('Component which extends Time mixin should implement tick()', !!this.tick);
        var interval = setInterval(function () {
            this.tick.apply(this);
        }.bind(this), 1000);
        this.set('timer', interval);
        this._super.apply(this, arguments);
    },
    willDestroy() {
        clearInterval(this.get('timer'));
    }
});
