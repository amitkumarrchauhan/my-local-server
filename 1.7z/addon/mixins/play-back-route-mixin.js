import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Mixin.create({
    willPlaybackRoues: true,
    beforeModel(transition) {
        var applicationController = getOwner(this).lookup('controller:application'),
            dockedRoute = applicationController.get('dockedRoute'),
            dockPaneController = getOwner(this).lookup('controller:dockPane');
        applicationController.set('playBackTransition', transition);
        if (!!dockedRoute) {
            dockPaneController.set('dockModeComponent', dockedRoute.get('dockModeComponent'));
            dockPaneController.set('dockModel', dockedRoute.get('dockModel'));
            dockPaneController.set('dockedRoute', dockedRoute);
            this.set('showDockPane', true);
        } else {
            dockPaneController.set('dockModeComponent', null);
            dockPaneController.set('dockModel', null);
            this.set('showDockPane', false);
        }
    }
});
