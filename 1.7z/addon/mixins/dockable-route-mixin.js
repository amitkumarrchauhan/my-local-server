import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Mixin.create({
    canBeDocked: true,
    showDockPane: false,
    init: function () {
        Ember.assert('dockModeComponent must be defined', !!this.get('dockModeComponent'));
        this._super();
    },
    beforeModel(transition) {
        var applicationController = getOwner(this).lookup('controller:application');
        applicationController.set('dockableRouteTransition', transition);
        this._super(arguments);
    },

    actions: {
        toggle: function () {
            var applicationController = getOwner(this).lookup('controller:application'),
                playbackTransition = applicationController.get('playBackTransition');
            if (playbackTransition !== undefined) {
                getOwner(this).lookup('controller:application').set('dockedRoute', this);
                playbackTransition.retry();
            }
        }
    },
    dockModel: Ember.computed({
        get() {
            return this.get('currentModel');
        }
    })
});
