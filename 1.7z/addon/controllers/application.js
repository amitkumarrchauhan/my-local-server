import Ember from 'ember';
import ApplicationController from 'supdash-ui-core/controllers/application';

export default ApplicationController.extend({
    queryParams: ['iframe'],
    iframe: null,
    hideLiveFeed: true,
    /**
    * Computed property to check if app is running in iframe mode
    */
    isIframeMode : Ember.computed('iframe', function () {
        var isIframe = this.get('iframe');
        if (isIframe) {
            sessionStorage.iframeMode = isIframe;
        }
        if (sessionStorage.iframeMode === "true") {
            return true;
        }
        return false;
    }),

    isLiveFeedHidden: Ember.computed('hideLiveFeed', function () {
        if (this.get('hideLiveFeed') === false) {
            return false;
        }
        return true;
    }),

    /**
    * Computed property for width for content container.
    * Observes for changes in hideSecondaryNav and isIframeMode properties, and changes with respectively
    */
    contentPlaceHolderWidth : Ember.computed('hideSecondaryNav', 'isLiveFeedHidden', 'showDockPane', function () {
        var contentWidth = 9;
        var hideSecondaryNav = this.get('hideSecondaryNav');
        var showDockPane = this.get('showDockPane');

        if (hideSecondaryNav === true && showDockPane === false) {
            contentWidth += 3;
        }
        return 'col-sm-' + contentWidth;
    })
});
