import Ember from 'ember';

export default Ember.Controller.extend({
  session: Ember.inject.service(),
  applicationController: Ember.inject.controller('application'),
  coreAuthentication: Ember.inject.service(),
  userProfileService: Ember.inject.service(),
  userProfile: Ember.computed.alias('userProfileService.userProfile'),
  init: function () {

    this.setAppTitle();

    this._super.apply(this, arguments);
  },

  setAppTitle(title) {
    var appTitle = this.get('applicationController').namespace.name;

    if (!title || appTitle === title) {
      this.set('baseAppTitle', appTitle);
      this.setAppVersion(this.get('applicationController').namespace.version);
      this.setNavIcon('mdi-menu');
    } else {
      this.set('baseAppTitle', title);
      this.setAppVersion('');
      this.setNavIcon('mdi-arrow-left');
    }
  },

  setNavIcon(iconCls) {
    this.set('topBarNavIcon', iconCls);
  },

  setAppVersion(version) {
      this.set('baseAppVersion', version ? ' : ' + version : '');
  },

  actions: {
    toggleUserProfileMenus() {
      this.set('profileMenuVisible', !this.get('profileMenuVisible'));
    },

    invalidateSession() {
      this.get('coreAuthentication').invalidate().then(() => {
        this.get('session').invalidate();
      });
    },

    toggleView(className) {
      console.log(className);
    }
  }
});
