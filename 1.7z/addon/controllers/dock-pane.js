import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Controller.extend({
    actions: {
        clearDock() {
            var applicationController = getOwner(this).lookup('controller:application'),
                dockedRouteTransition = applicationController.get('dockableRouteTransition');
            if (!!dockedRouteTransition) {
                dockedRouteTransition.retry();
            }
            applicationController.set('dockedRoute', null);
            applicationController.set('dockableRouteTransition', null);
        },
        clearDockWithoutRedirect() {
            var applicationController = getOwner(this).lookup('controller:application');
            applicationController.set('dockedRoute', null);
            applicationController.set('dockableRouteTransition', null);
        }
    }
});
