import Ember from 'ember';
import layout from '../templates/components/app-version';
const { getOwner } = Ember;

export default Ember.Component.extend({
  tagName: 'span',
  layout: layout,
  version: Ember.computed(function() {
    return getOwner(this).lookup('application:main').version;
  }),
  environment: Ember.computed(function() {
    var env = Ember.$('meta[name=environment]');
    if (env.length > 0 && env[0].content !== "@@CURRENT_ENVIRONMENT") {
      return env[0].content;
    } else {
      return 'Dev';
    }
  }),
  getModules: function() {
    return getOwner(this).lookup('service:core-module-loader').moduleDefinitions;
  },
  didInsertElement() {
    var allModules = this.getModules(),
      modules = [],
      module;

    for (module in allModules) {
      var moduleObj = allModules[module];
      var version = moduleObj.ignoreModuleVersion ? getOwner(this).lookup('application:main').version : moduleObj.version;

      modules.push(module + " : " +version);
    }
    this.$().tooltip({
      title: modules.join("<br/>"),
      placement: 'bottom',
      html: true
    });
  }
});
