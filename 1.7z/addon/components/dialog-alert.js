import Ember from 'ember';
import layout from '../templates/components/dialog-alert';

export default Ember.Component.extend({
    layout: layout,
    /**
       * Close property of the dialog box.
       *
       * @property {boolean} closable
       * @default  false
       */
    closable: false,
    /**
       * title text of the dialog box.
       *
       * @property {string} title
       * @default  null
       */
    title: null,
    /**
       * show Function, binded to didInsertElement event- this will show the dialog box component
       *
       * @function show
       * @returns  {void}
       */
    show: Ember.on('didInsertElement', function () {
        this.dialogManager.set('activeDialog', this.$('.modal').modal({
            backdrop: 'static',
            keyboard: false
        }).on('hidden.bs.modal',
        function () {
            this.sendAction('close');
        }.bind(this)));
    }),
    willDestroyElement: function () {
        this.destroy();
    },
    okBtnText: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.OK.text') || 'OK';
        }
    }),
    okBtnType: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.OK.type') || 'flat-primary';
        }
    }),
    actions: {
        ok() {
            this.get('config.onClose').call(this.get('config.callbackContext'));
        }
    }
});
