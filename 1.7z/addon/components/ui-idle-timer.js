import Ember from 'ember';
import layout from '../templates/components/ui-idle-timer';
import Timer from 'supdash-ui-base/mixins/timer';
import AppConst from 'supdash-ui-core/utils/app-const';
const { getOwner } = Ember;
//import request from 'ic-ajax';

export default Ember.Component.extend(Timer, {
    layout: layout,
    timeout: 1200000,
    timeoutWarning: 1020000,
    /*timeout: 60000,
    timeoutWarning: 30000,*/
    coreAuthentication: Ember.inject.service(),
    mdFlashMessages: Ember.inject.service(),
    lastUserAction: new Date().getTime(),
    coreRequestAuthorizer: Ember.inject.service(),
    lastUserInteractionTime: Ember.computed('coreRequestAuthorizer.lastRequestTime', 'lastUserAction', {
        get() {
            return this.get('lastUserAction') > this.get('coreRequestAuthorizer.lastRequestTime') ? this.get('lastUserAction') : this.get('coreRequestAuthorizer.lastRequestTime');
        }
    }),
    init() {
        Ember.assert('timeout cannot be smaller than timeoutWarning', this.get('timeout') >= this.get('timeoutWarning'));
        this._super.apply(this, arguments);
    },
    tick() {
        var currentTime = new Date().getTime(),
            idleTime = currentTime - this.get('lastUserInteractionTime'),
            timeRemaining = this.get('timeout') - idleTime, minutes, flash;
            //_this = this;

        if (idleTime >= this.get('timeoutWarning') && idleTime < this.get('timeout')) {
            minutes = moment.duration(timeRemaining).minutes();
            this.set('isShowingWarning', true);
            flash = this.get('sessionWarningFlash');
            if (flash == null) {
                flash = this.get('mdFlashMessages').success('Your session will expire in ' + minutes + (minutes > 1 ? ' minutes' : ' minute') + ' and ' +  (parseInt((timeRemaining / 1000) % 60)) + ' seconds', {
                    sticky: true
                });
                flash.on('didDestroyMessage', function () {
                    this.resetTimerAtServer(flash);
                    /*request('/api/auth/user/session/touch').then(function () {
                        this.set('lastUserAction', new Date().getTime());
                        this.set('sessionWarningFlash', null);
                        if (flash != null) {
                            flash = null;
                        }
                    }.bind(this));*/

                }.bind(this));
                this.set('sessionWarningFlash', flash);
            } else {
                if (flash) {
                    flash.set('message', 'Your session will expire in ' + minutes + (minutes > 1 ? ' minutes' : ' minute') + ' and ' +  (parseInt((timeRemaining / 1000) % 60)) + ' seconds');
                }
            }
        } else if (idleTime >= this.get('timeout')) {
            this.mdFlashMessages.clearMessages();
            getOwner(this).lookup('controller:application').send('invalidateSession');
        }
    },
    resetTimerAtServer(flash) {
        var lastUserActionTime = this.get('lastUserAction');
        var lastServerInformed = this.get('serverInformed') ? this.get('serverInformed') : lastUserActionTime;
        var timeSinceServerInformed = lastUserActionTime - lastServerInformed;

        if (!timeSinceServerInformed || timeSinceServerInformed >= this.timeoutWarning && timeSinceServerInformed < this.timeout) {
            var coreAuthentication = this.get('coreAuthentication');
            var url = coreAuthentication.hostURL + coreAuthentication.apiURL + '/validate';

            Ember.$.ajax({
                url: url,
                beforeSend: (jqXHR) => {
                    var coreRequestAuthorizer = this.get('coreRequestAuthorizer');

                    jqXHR.setRequestHeader(AppConst.APP_TOKEN_NAME, coreRequestAuthorizer.get('session.secure.'+ AppConst.APP_TOKEN_KEY));
                    jqXHR.setRequestHeader(AppConst.APP_REQUEST_ID, coreRequestAuthorizer.get('requestID'));
                },
                success: () => {
                    this.set('serverInformed', new Date().getTime());

                    if (flash) {
                        this.set('sessionWarningFlash', null);
                        flash = null;
                    }
                }
            });
        }
    },
    resetTimer() {
        var resetTime = new Date().getTime();
        Ember.Logger.debug('User Activity Detected: ' + resetTime);

        this.set('lastUserAction', resetTime);
        this.resetTimerAtServer();
    },
    touchstart: function () {
        this.resetTimer();
    },
    touchmove: function () {
        this.resetTimer();
    },
    touchend: function () {
        this.resetTimer();
    },
    touchcancel: function () {
        this.resetTimer();
    },
    keydown: function () {
        this.resetTimer();
    },
    keyup: function () {
        this.resetTimer();
    },
    keypress: function () {
        this.resetTimer();
    },
    mousedown: function () {
        this.resetTimer();
    },
    mouseup: function () {
        this.resetTimer();
    },
    contextmenu: function () {
        this.resetTimer();
    },
    click: function () {
        this.resetTimer();
    },
    dblclick: function () {
        this.resetTimer();
    },
    mousemove: function () {
        this.resetTimer();
    },
    focusin: function () {
        this.resetTimer();
    },
    focusout: function () {
        this.resetTimer();
    },
    mouseenter: function () {
        this.resetTimer();
    },
    mouseleave: function () {
        this.resetTimer();
    },
    submit: function () {
        this.resetTimer();
    },
    input: function () {
        this.resetTimer();
    },
    change: function () {
        this.resetTimer();
    },
    dragstart: function () {
        this.resetTimer();
    },
    drag: function () {
        this.resetTimer();
    },
    dragenter: function () {
        this.resetTimer();
    },
    dragleave: function () {
        this.resetTimer();
    },
    dragover: function () {
        this.resetTimer();
    },
    drop: function () {
        this.resetTimer();
    },
    dragend: function () {
        this.resetTimer();
    }
});
