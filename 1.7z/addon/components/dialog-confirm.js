import Ember from 'ember';
import layout from '../templates/components/dialog-confirm';

export default Ember.Component.extend({
    layout: layout,
    /**
       * Close property of the dialog box.
       *
       * @property {boolean} closable
       * @default  false
       */
    closable: false,
    /**
       * title text of the dialog box.
       *
       * @property {string} title
       * @default  null
       */
    title: null,
    /**
       * show Function, binded to didInsertElement event- this will show the dialog box component
       *
       * @function show
       * @returns  {void}
       */
    show: Ember.on('didInsertElement', function () {
        this.dialogManager.set('activeDialog', this.$('.modal').modal({
            backdrop: 'static',
            keyboard: false
        }).on('hidden.bs.modal',
        function () {
            this.sendAction('close');
        }.bind(this)));
    }),
    willDestroyElement: function () {
        this.destroy();
    },
    okBtnText: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.OK.text') || 'OK';
        }
    }),
    okBtnType: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.OK.type') || 'flat-alert';
        }
    }),
    cancelBtnText: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.cancel.text') || 'Cancel';
        }
    }),
    cancelBtnType: Ember.computed('config', {
        get() {
            return this.get('config.componentConfig.btnConfig.cancel.type') || 'flat-secondary';
        }
    }),
    actions: {
        ok() {
            this.get('config.onOk').call(this.get('config.callbackContext'));
        },
        cancel() {
            this.get('config.onCancel').call(this.get('config.callbackContext'));
        }
    }
});

