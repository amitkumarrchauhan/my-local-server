import Ember from 'ember';
import layout from '../templates/components/ui-responsive-app';

export default Ember.Component.extend({
    layout: layout,
    classNameBindings: ['media.classNames']
});
