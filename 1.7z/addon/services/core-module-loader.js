import coreModuleLoader from 'supdash-ui-core/services/core-module-loader';

export default coreModuleLoader;
