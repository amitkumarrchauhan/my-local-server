import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
    getApplicationController() {
        return getOwner(this).lookup('controller:application');
    },
    getPromise() {
        return new Ember.RSVP.Promise(function (resolve, reject) {
            this.set('resolve', resolve);
            this.set('reject', reject);
        }.bind(this));
    },
    onConfirmReject() {
        this._closeDialog();
        this.get('reject')();
    },
    onConfirmAccept() {
        this._closeDialog();
        this.get('resolve')();
    },
    onAlertClose() {
        this._closeDialog();
        this.get('resolve')();
    },

    _closeDialog() {
        this.set('activeDialog', undefined);
        var controller = this.getApplicationController();
        controller.setProperties({
            displayDialog: false,
            dialogComponent: null,
            dialogConfig: null
        });
    },


    confirm(componentConfig) {
        Ember.run.next(function () {
            var controller = this.getApplicationController();
            controller.setProperties({
                displayDialog: true,
                dialogComponent: 'dialog-confirm',
                dialogConfig: {
                    componentConfig: componentConfig,
                    onCancel: this.onConfirmReject,
                    onOk: this.onConfirmAccept,
                    callbackContext: this,
                    onEscape: this.onConfirmReject
                }
            });
        }.bind(this));
        return this.getPromise();
    },

    alert(componentConfig) {
        Ember.run.next(function () {
            var controller = this.getApplicationController();
            controller.setProperties({
                displayDialog: true,
                dialogComponent: 'dialog-alert',
                dialogConfig: {
                    componentConfig: componentConfig,
                    onClose: this.onAlertClose,
                    callbackContext: this,
                    onEscape: this.onAlertClose
                }
            });
        }.bind(this));
        return this.getPromise();
    },
    closeOnEscape () {
        var dialogConfig, activeDialog = this.get('activeDialog');
        if (activeDialog) {
            dialogConfig = this.getApplicationController().get('dialogConfig');
            activeDialog.modal('hide');
            dialogConfig.onEscape.apply(dialogConfig.callbackContext);
        }
    }
});
