import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
    activeFlyout: null,
    getApplicationController() {
        return getOwner(this).lookup('controller:application');
    },
    openFlyout(componentName, config) {
        var controller = this.getApplicationController();
        controller.set('aboutToDisplayFlyout', true);
        Ember.run.next(function () {
            controller.setProperties({
                displayFlyout: true,
                displayFlyoutModal: true,
                flyoutComponent: componentName,
                flyoutConfig: config
            });
        });
    },
    closeOnEscape () {
        var activeFlyout = this.get('activeFlyout');
        // If there is any activeFlyout. We are closing it
        if (activeFlyout) {
            this.get('activeFlyout').send('close');
        }
    },
    closeFlyout() {
        var controller = this.getApplicationController();
        this.set('activeFlyout', undefined);
        controller.setProperties({
            displayFlyout: false
        });
        Ember.run.later(function () {
            controller.setProperties({
                displayFlyoutModal: false,
                aboutToDisplayFlyout: false,
                flyoutComponent: null,
                flyoutConfig: null
            });
        }, 500);
    },
    transitionTo() {
        var controller = this.getApplicationController(),
            currentRoute = getOwner(this).lookup('route:' + controller.get('currentRouteName'));
        currentRoute.transitionTo.apply(currentRoute, arguments);
    }
});
