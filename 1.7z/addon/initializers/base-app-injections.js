export function initialize(application) {
    // application.inject('route', 'foo', 'service:foo');
    application.inject('component', 'flyoutManager', 'service:flyout-manager');
    application.inject('route', 'flyoutManager', 'service:flyout-manager');
    application.inject('controller', 'flyoutManager', 'service:flyout-manager');
    application.inject('component', 'dialogManager', 'service:dialog-manager');
    application.inject('route', 'dialogManager', 'service:dialog-manager');
    application.inject('controller', 'dialogManager', 'service:dialog-manager');
}

export default {
    name: 'base-app-injections',
    initialize: initialize
};
