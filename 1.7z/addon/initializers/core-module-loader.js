export function initialize(application) {
    application.register('service:core-module-loader', 'core-module-loader', { singleton: true });
    application.inject('route', 'moduleLoader', 'service:core-module-loader');
    application.inject('component', 'moduleLoader', 'service:core-module-loader');
    application.inject('service:core-module-loader', 'application', 'application:main');

    // Injects core-module-loader service into resolver instance.
    application.__registry__.resolver.reopen({
        moduleLoader: application.__container__.lookup('service:core-module-loader')
    });
}

export default {
    name: 'core-module-loader',
    initialize: initialize
};
