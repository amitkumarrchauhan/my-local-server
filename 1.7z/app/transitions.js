import Ember from "ember";

export default function () {

    this.transition(
        this.hasClass('displaying-dialog'),
        this.toValue(true),
        this.use('toLeft'),
        this.reverse('toRight')
      );
}
