import ApplicationController from 'supdash-ui-base/controllers/application';

export default ApplicationController;
