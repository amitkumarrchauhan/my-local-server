export { default } from 'supdash-ui-base/controllers/top-bar';
