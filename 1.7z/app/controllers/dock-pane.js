export { default } from 'supdash-ui-base/controllers/dock-pane';
