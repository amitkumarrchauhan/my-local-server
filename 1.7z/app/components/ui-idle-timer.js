export { default } from 'supdash-ui-base/components/ui-idle-timer';
