export { default } from 'supdash-ui-base/components/dialog-alert';
