import Ember from 'ember';
const { getOwner } = Ember;

export function initialize() {
    var getRouteName, getCurrentRouteName, lookupRouteInCurrentModule;
    getRouteName = function () {
        return Ember.__loader.require('ember-metal/streams/utils').read(this.attrs.params[0]);
    };

    getCurrentRouteName = function () {
        var routeName = getOwner(this).lookup('controller:application').get('currentRouteName'),
            router;
        if (routeName === undefined) {
            router = getOwner(this).lookup('router:main').router;
            if (router != null && router.state != null && router.state.handlerInfos != null && router.state.handlerInfos.length > 0) {
                routeName = router.state.handlerInfos[router.state.handlerInfos.length - 1].name;
            }
        }

        return routeName;
    };

    lookupRouteInCurrentModule = function () {
        try {
            return this._super.apply(this, arguments);
        } catch (e) {
            var currentRouteName =
                getOwner(this).lookup('controller:application').get('currentRouteName'),
                moduleName, url, moduleLoader = getOwner(this).lookup('service:core-module-loader');
            moduleName = currentRouteName.split('.')[0];

            try {
                require(moduleName + '/routes/' + getRouteName.call(this));
                return;
            } catch (err) {
                url = getOwner(this).lookup('router:main').get('url').split('/')[1];
                moduleName = moduleLoader._getModuleName(url);
                try {
                    require(moduleName + '/routes/' + getRouteName.call(this));
                    return;
                } catch (error) {
                    throw e;
                }
            }
        }
    };

    Ember.LinkComponent.reopen({
        willRender: function () {
            var targetRouteParam, currentRouteName, routeName, moduleName, tempRouteName, tempRoute,
                recognizer = getOwner(this).lookup('router:main').router.recognizer;

            targetRouteParam = getRouteName.call(this);
            currentRouteName = getCurrentRouteName.call(this);

            // If the passed route name is not available in the router, checks
            // if the route is available as sub route of the current route and manipulates
            // this.attrs.params[0] accordingly
            if (getOwner(this).lookup('router:main').router.recognizer.names[targetRouteParam] === undefined) {
                if (getOwner(this).lookup('router:main').router.recognizer.names[getCurrentRouteName.apply(this).split('.')[0] + '.' + targetRouteParam] !== undefined) {
                    if (typeof this.attrs.params[0] === "string") {
                        this.attrs.params[0] = getCurrentRouteName.apply(this).split('.')[0] + '.' + this.attrs.params[0];
                    } else {
                        this.attrs.params[0].wbValue = this.attrs.params[0].value;

                        this.attrs.params[0].value = function () {
                            var oldVal = this.wbValue();
                            return currentRouteName.split('.')[0] + '.' + oldVal;
                        }
                    }
                }

                // handles fsPage && fsForm
                if (targetRouteParam === 'fsPage' || targetRouteParam === 'fsForm') {
                    //detect the fsForm route.
                    tempRouteName = currentRouteName;
                    //tempRoute = tempRouteName;
                    while (tempRouteName.indexOf('.') !== -1) {
                        tempRoute = tempRouteName + '.' + targetRouteParam;
                        if (recognizer.names[tempRoute] !== undefined) {
                            break;
                        }
                        tempRouteName = tempRouteName.replace(/\.[^.]*?$/, '');
                    }

                    if (recognizer.names[tempRoute] === undefined) {
                        tempRoute = tempRouteName + '.' + targetRouteParam;
                    }

                    this.attrs.params[0] = tempRoute;
                }
            }

            this._super.apply(this, arguments);

            routeName = getRouteName.call(this);
            moduleName = routeName.split('.')[0];

            this.set('moduleName', moduleName);
            this.set('__invoke', this.get('_invoke'));
        },

        active: Ember.computed("attrs.params", "_routing.currentState", function computeLinkToComponentActive() {
            var moduleLoader = getOwner(this).lookup('service:core-module-loader');
            if (moduleLoader.isSubModulePattern(this.get('moduleName')) === true &&
              moduleLoader.isModuleLoaded(this.get('moduleName')) === false) {
                return;
            } else {
                //return this._super.apply(this, arguments);
                return lookupRouteInCurrentModule.apply(this, arguments);
            }
        }),

        willBeActive: Ember.computed("_routing.targetState", function computeLinkToComponentWillBeActive() {
            var moduleLoader = getOwner(this).lookup('service:core-module-loader');
            if (moduleLoader.isSubModulePattern(this.get('moduleName')) === true &&
              moduleLoader.isModuleLoaded(this.get('moduleName')) === false) {
                return;
            } else {
                //return this._super.apply(this, arguments);
                return lookupRouteInCurrentModule.apply(this, arguments);
            }
        }),

        loading: Ember.computed("models", "targetRouteName", function () {
            var moduleLoader = getOwner(this).lookup('service:core-module-loader');
            if (moduleLoader.isSubModulePattern(this.get('moduleName')) === true &&
                moduleLoader.isModuleLoaded(this.get('moduleName')) === false) {
                return;
            } else {
                //return this._super.apply(this, arguments);
                return lookupRouteInCurrentModule.apply(this, arguments);
            }
        }),

        disabled: Ember.computed(function () {
            var moduleLoader = getOwner(this).lookup('service:core-module-loader');
            if (moduleLoader.isSubModulePattern(this.get('moduleName')) === true &&
                moduleLoader.isModuleLoaded(this.get('moduleName')) === false) {
                return;
            } else {
                //return this._super.apply(this, arguments);
                return lookupRouteInCurrentModule.apply(this, arguments);
            }
        }),

        qualifiedRouteName: Ember.computed('targetRouteName', '_routing.currentState', function computeLinkToComponentQualifiedRouteName() {
            var targetRouteParam = getRouteName.call(this);
            if (getOwner(this).lookup("router:main").router.recognizer.names[targetRouteParam] === undefined) {
                return '#';
            } else {
                return this._super.apply(this, arguments);
            }
        }),

        href: Ember.computed('models', 'qualifiedRouteName', function computeLinkToComponentHref() {
            var targetRouteParam = getRouteName.call(this);
            if (getOwner(this).lookup("router:main").router.recognizer.names[targetRouteParam] === undefined) {
                return '#';
            } else {
                return this._super.apply(this, arguments);
            }
        }),

        transitioningIn: Ember.computed('active', 'willBeActive', function computeLinkToComponentTransitioningIn() {
            var targetRouteParam = getRouteName.call(this);
            if (getOwner(this).lookup("router:main").router.recognizer.names[targetRouteParam] === undefined) {
                return '#';
            } else {
                return this._super.apply(this, arguments);
            }
        }),

        transitioningOut: Ember.computed('active', 'willBeActive', function computeLinkToComponentTransitioningOut() {
            var targetRouteParam = getRouteName.call(this);
            if (getOwner(this).lookup("router:main").router.recognizer.names[targetRouteParam] === undefined) {
                return '#';
            } else {
                return this._super.apply(this, arguments);
            }
        }),

        _invoke: function (e) {
            if (Ember.__loader.require('ember-views/system/utils').isSimpleClick(e) !== true) {
                return;
            }
            e.preventDefault();

            var moduleLoader = getOwner(this).lookup('service:core-module-loader'),
            moduleName = this.get('moduleName'),
            self = this, superInvoke = this.__nextSuper;
            //if (this.router.router.reg)
            if (getOwner(this).lookup('router:main').router.recognizer.names[getRouteName.call(this)] !== undefined) {
                this._super(e);
            } else {
                moduleLoader.loadModule(moduleName).then(function () {
                    if (self.__nextSuper === undefined) {
                        self.__nextSuper = superInvoke;
                    }
                    self._super(e);
                });
            }

            return false;
        }
    });
}

export default {
    name: 'lazy-link-view',
    initialize: initialize
};
