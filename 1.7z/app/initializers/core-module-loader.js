export { default, initialize } from 'supdash-ui-base/initializers/core-module-loader';
