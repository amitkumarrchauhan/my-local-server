import Ember from 'ember';
const { getOwner } = Ember;

export function initialize(/* container, application */) {
    var Route = Ember.__loader.require('ember-routing/system/route').default;
    Route.reopen({
        transitionTo: function (name/*, context*/) {
            var moduleLoader = getOwner(this).lookup('service:core-module-loader'), currentRouteName = getOwner(this).lookup('controller:application').get('currentRouteName'),
                currentModuleName, args, targetRouteName,
                url = this.router.get('url');
            this.originalArgs = Array.prototype.slice.call(arguments);

            if (typeof name === 'string' && name.indexOf('/') === -1 && this.router.router.recognizer.names[name] === undefined) {
                currentModuleName = moduleLoader.getModuleNameFromURL(url) ||
                    moduleLoader.getCurrentModuleNameFromRoute(currentRouteName) ||
                    moduleLoader.getCurrentModuleNameFromActiveTransition();

                if (currentModuleName != null) {
                    targetRouteName = currentModuleName + '.' + name;
                    if (this.router.router.recognizer.names[targetRouteName] !== undefined) {
                        args = Array.prototype.slice.call(arguments);
                        args[0] = targetRouteName;
                        this._super.apply(this, args);
                        return;
                    }
                } else if (moduleLoader.isSubModulePattern(name) === true) {
                    if (moduleLoader.isModuleLoaded(name.split('.')[0]) === false) {
                        moduleLoader.loadModule(name.split('.')[0]).then(function () {
                            this.transitionTo.apply(this, this.originalArgs);
                        }.bind(this));
                        return;
                    }
                }

            }
            this._super.apply(this, arguments);
        }
    });
}

export default {
    name: 'lazy-link-to',
    after: 'core-module-loader',
    initialize: initialize
};
