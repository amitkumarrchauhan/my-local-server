export { default, initialize } from 'supdash-ui-base/initializers/base-app-injections';
