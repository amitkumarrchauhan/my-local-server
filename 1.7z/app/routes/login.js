import Route from 'supdash-ui-base/routes/login';

export default Route;
