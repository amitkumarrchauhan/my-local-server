import Route from 'supdash-ui-base/routes/error';

export default Route;
