import Route from 'supdash-ui-base/routes/application';

export default Route;
