export { default } from 'supdash-ui-base/templates/login';
