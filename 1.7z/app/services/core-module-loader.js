import coreModuleLoader from 'supdash-ui-base/services/core-module-loader';


export default coreModuleLoader;
