import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
    firstName: DS.attr('string'),
    lastName: DS.attr('string'),
    imageLink: DS.attr('string'),
    email: DS.attr('string'),
    roleHead: DS.attr('string'),
    psId: DS.attr('string'),
    pseudoId: DS.attr('string'),
    department: DS.attr('string'),
    jobTitle: DS.attr('string'),
    shortDescription: DS.attr('string'),
    userCountry: DS.attr('string'),
    roleHeadType: DS.attr('number'),
    atwUserType: DS.attr('number'),
    atwUser: DS.attr('string'),
    ldapRoles: DS.attr(),
    fullName: Ember.computed('firstName', 'lastName', {
        get: function () {
            return this.get('firstName') + ' ' + this.get('lastName');
        }
    }),
    imageUrl: Ember.computed('imageLink', {
        get () {
            var imageLink = this.get('imageLink');
            return imageLink ? imageLink : 'supdash-ui-base/images/user-photo.jpg';
        }
    })
});
