import Ember from 'ember';
export function initialize(application) {
  Ember.onerror = function(error) {
    if (error.supress !== true && !error.errorHandled) {
      var errorMsg = "Error occured.";

      if (error) {
        if (typeof error === "string") {
          errorMsg = error;
        } else if (error.errors instanceof Array && error.errors.length > 0) {
          if (error.errors[0].status === "502") {
            errorMsg = "Status 502 - Proxy Error";
          } else {
            errorMsg = error.errors[0].code + " - " + error.errors[0].detail + '- Error ID: ' + error.errors[0].id;
          }
        }
      }

      Ember.Logger.error(error.stack);
      this.__container__.lookup('service:mdFlashMessages').success(errorMsg, {
        sticky: true
      });

      return false;
    }
  }.bind(application);
}

export default {
  name: 'error-handler',
  initialize: initialize
};
