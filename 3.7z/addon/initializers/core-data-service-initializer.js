import CoreDataService from 'supdash-ui-core/services/core-data-service';

export function initialize(application) {
    application.register('CoreDataService:main', CoreDataService, {singleton: true, instantiate: true});
    application.inject('route', 'coreDataService', 'CoreDataService:main');
    application.inject('component', 'coreDataService', 'CoreDataService:main');
}

export default {
    name: 'core-data-service-initializer',
    initialize: initialize
};
