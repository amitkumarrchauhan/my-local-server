import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
  getUsers (options) {
    return this.retriveFromStore("user", options);
  },

  getStore () {
    return getOwner(this).lookup('service:store');
  },

  query(modelName, options) {
    var store = this.getStore();

    if (options) {
      return store.query(modelName, options);
    }

    return store.findAll(modelName);
  },

  queryRecord(modelName, options) {
    var store = this.getStore();

    return store.queryRecord(modelName, options);
  }
});
