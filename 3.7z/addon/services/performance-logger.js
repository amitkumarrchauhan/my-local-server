import Ember from 'ember';

export default Ember.Service.extend({
    init: function () {
        this._super.apply(this, arguments);
        this._restoreLogger();
    },
    /**
     * @private
     * Initializes the logger if the config.enabled === true
     **/
    initLogger: function (config) {
        this.perfConfig = config;
        if (config.enabled === true) {
            this._enablePerformanceLogging();
            this.enabled = true;
        } else {
            this.enabled = false;
            this._disablePerformanceLogging();
        }
        localStorage.perfLoggerConfig = JSON.stringify(config);
    },

    /**
     * @Public
     **/
    enable: function () {
        this._enablePerformanceLogging();
    },

    /**
     * @Public
     **/
    disable: function () {
        this._disablePerformanceLogging();
    },

    /**
     * @Private
     * Removes the patch applied on $.ajax for performance logging
     **/
    _disablePerformanceLogging: function () {
        if (this.oldAjax) {
            Ember.$.ajax = this.oldAjax;
        }
    },

    /**
     * @Private
     * Restores the config from the localStorage on browser refresh
     **/
    _restoreLogger: function () {
        if (localStorage.perfLoggerConfig) {
            this.initLogger(JSON.parse(localStorage.perfLoggerConfig));
        }
    },

    /**
     * @private
     * Enables the performance logging for the current user if the perfomance logging
     * is enabled in the userProfile.
     * This is achieved by patching the jquery ajax which is internally used by Ember.
     **/
    _enablePerformanceLogging: function () {
        if (this.enabled === true) {
            return;
        }
        var _this = this;
        this.oldAjax = Ember.$.ajax;
        Ember.$.ajax = function (config) {
            if (config.disablePerfLogging !== true) {
                if (config.beforeSend) {
                    config.actualBeforeSend = config.beforeSend;
                }
                config.beforeSend = function (xhr, settings) {
                    xhr.startTime = new Date();
                    if (settings.actualBeforeSend) {
                        settings.actualBeforeSend.apply(this, arguments);
                    }
                    xhr.settings = settings;
                };

                if (config.complete) {
                    config.actualComplete = config.complete;
                }
                config.complete = function (xhr) {
                    xhr.endTime = new Date();

                    _this.oldAjax({
                        data: {
                            url: xhr.settings.url,
                            type: xhr.settings.type,
                            timeTaken: ((xhr.endTime - xhr.startTime) / 1000)
                        },
                        url: _this.perfConfig.loggingURL,
                        type: 'POST',
                        dataType: 'json'
                    });
                };
            }
            return _this.oldAjax(config);
        };
    }
});
