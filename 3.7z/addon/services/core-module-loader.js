import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
    init() {
        var app = this.application;
        this._super.apply(this, arguments);
        this.set('loadingModules', {});

        app.deferReadiness();
        app.ready = function () {
            Ember.run.next(function () {
                this.mapRouteFromStartupQueue();
            }.bind(this));
        }.bind(this);

        // Loads module config json through synchronous ajax request.
        var _this = this;
        this._loadModuleDependencyConfig(function () {
            _this.contextPathHash = {};
            _this._validateModuleDefinition();
            _this._mapOnStartupQueue = [];

            _this._loadStartupModules().then(function () {
                app.advanceReadiness();
            });

            _this.isLoaded = true;
        });
    },

    mapRouteFromStartupQueue() {
        for (var i = 0, len = this._mapOnStartupQueue.length; i < len; i++) {
            this._mapDynamically(this._mapOnStartupQueue[i].moduleName, this._mapOnStartupQueue[i].routeMap);
        }
        this._mapOnStartupQueue = [];
    },

    _loadStartupModules() {
        var moduleName, moudleConfig, toBeLoadedOnStartup = [], dependenciesList = [];
        for (moduleName in this.moduleDefinitions) {
            if (this.application.modulePrefix !== moduleName) {
                moudleConfig = this.moduleDefinitions[moduleName];
                if (moudleConfig['load-on-startup'] === true) {
                    toBeLoadedOnStartup.push(moduleName);
                    if (moudleConfig.dependencies && moudleConfig.dependencies.length) {
                        dependenciesList = dependenciesList.concat(this.moduleDefinitions[moduleName].dependencies);
                    }
                }
            }
        }
        return new Ember.RSVP.Promise(function (resolve, reject) {
            async.each(toBeLoadedOnStartup, function (item, cb) {
                    if (dependenciesList.indexOf(item) === -1) {
                        this.loadModule(item).then(function () {
                            cb();
                        })['catch'](function (err) {
                            cb(err);
                        });
                    } else {
                        cb();
                    }
                }.bind(this), function (err) {
                    if (err != null) {
                        reject(err);
                    } else {
                        resolve();
                    }
                });
        }.bind(this));
    },

    _validateModuleDefinition() {
        if (this.moduleDefinitions == null) {
            throw new Error('Module definition not found!');
        }

        for (var k in this.moduleDefinitions) {
            if (this.moduleDefinitions[k].contextPath !== undefined) {
                if (this.moduleDefinitions[this.moduleDefinitions[k].contextPath] !== undefined) {
                    throw new Error("contextPath of " + k + " module " +
                        this.moduleDefinitions[k].contextPath + " is defined as a seperate module.");
                } else {
                    this.contextPathHash[this.moduleDefinitions[k].contextPath] = k;
                }
            }
        }

        return true;
    },

    /**
     * Returns contextPath of the moduleName supplied.
     * If no contextPath is defined for the module, moduleName is returned as contextPath
     * If no module is found with the passed moduleName, null is returned.
     **/
    getContextPath(moduleName) {
        moduleName = this._getModuleName(moduleName);
        if (moduleName && this.moduleDefinitions[moduleName] !== undefined) {
            if (this.moduleDefinitions[moduleName].contextPath !== undefined) {
                return this.moduleDefinitions[moduleName].contextPath;
            }

            return moduleName;
        }

        return null;
    },

    _getModuleName(moduleName) {
        if (this.moduleDefinitions[moduleName] === undefined) {
            if (this.contextPathHash[moduleName] !== undefined) {
                return this.contextPathHash[moduleName];
            }
        }

        return moduleName;
    },

    _loadModuleDependencyConfig(callback) {
        var moduleJsonPath = this.application.moduleDefinitionPath || '/module.json';
        Ember.$.ajax({
            url: moduleJsonPath,
            dataType: 'json',
            cache: false,
            success: function (moduleConfig) {
                this.set('moduleDefinitions', moduleConfig.modules);
                if (moduleConfig.appConfig != null) {
                    this.set('appConfig', moduleConfig.appConfig);
                }

                if (callback) {
                  callback();
                }
            }.bind(this),
            error: function (/*xhr, setting, err*/) {
              Ember.Logger.warn('module.json not found.');

              this.set('moduleDefinitions', {
                "dummy": {
                  "path": "/assets/",
                  "load-on-startup": true,
                  "contextPath": "/"
                }
              });

              if (callback) {
                callback();
              }
            }.bind(this)
        });
    },

    handleDeps(moduleName) {
        moduleName = this._getModuleName(moduleName);
        return new Ember.RSVP.Promise(function (resolve, reject) {
            var i = 0, loadModuleHandlers = [], dependencies, self;
            if (moduleName === undefined || this.moduleDefinitions[moduleName] === undefined) {
                reject(new Error('Invalid module name'));
                return;
            }

            dependencies = this.moduleDefinitions[moduleName].dependencies;
            if (dependencies !== undefined &&
                dependencies.length > 0) {
                for (i = 0; i < dependencies.length; i++) {
                    if (this.get('loadingModules')[dependencies[i]] === undefined) {
                        loadModuleHandlers.push({fn: this.loadModule, moduleName: dependencies[i]});
                    } else {
                        reject(new Error('Module ' + dependencies[i] + ' is in loading state. It cannot be referenced'));
                        return;
                    }
                }

                self = this;
                async.each(loadModuleHandlers, function (item, cb) {
                    item.fn.apply(self, [item.moduleName]).then(function () {
                        cb();
                    })['catch'](function (err) {
                        cb(err);
                    });
                }, function (err) {
                    if (err != null) {
                        reject(err);
                    } else {
                        resolve();
                    }
                });

            } else {
                resolve();
            }
        }.bind(this));
    },

    /**
     * Fetches the script from server.
     **/
    loadModule(moduleName) {
        moduleName = this._getModuleName(moduleName);
        var promise = new Ember.RSVP.Promise(function (resolve, reject) {
            if (this.isModuleLoaded(moduleName) === false) {
                this.get('loadingModules')[moduleName] = moduleName;
                this.handleDeps(moduleName).then(function () {
                    var cssPath, jsPath;
                    if (this.moduleDefinitions[moduleName].version !== undefined) {
                        cssPath = this.moduleDefinitions[moduleName].path + moduleName + '-' + this.moduleDefinitions[moduleName].version + '.css';
                        jsPath = this.moduleDefinitions[moduleName].path + moduleName + '-' + this.moduleDefinitions[moduleName].version + '.js';
                    } else {
                        cssPath = this.moduleDefinitions[moduleName].path + moduleName + '.css';
                        jsPath = this.moduleDefinitions[moduleName].path + moduleName + '.js';
                    }
                    Ember.$('<link rel="stylesheet" href="' + cssPath + '"/>').appendTo('head');
                    Ember.$.ajax({
                        url: jsPath,
                        dataType: 'script',
                        cache: true
                    }).done(function () {
                        this.loadRoutesFromModule(moduleName);
                        this.loadTransitionsFromModule(moduleName);

                        // Marks the module as loaded.
                        this.get('moduleDefinitions')[moduleName].loaded = true;

                        // Remove the loading flag for the loaded module
                        delete this.get('loadingModules')[moduleName];
                        resolve(this.getModule(moduleName));
                    }.bind(this)).fail(function (req, setting, err) {
                        reject(err);
                    });
                }.bind(this))['catch'](function (err) {
                    reject(err);
                });
            } else {
                resolve(this.getModule(moduleName));
            }
        }.bind(this));

        return promise;
    },

    _mapDynamically(moduleName, callback) {
        var DSL, dsl, self = this, routeRegConfig = {};

        DSL = Ember.__loader.require("ember-routing/system/dsl").default;
        dsl = new DSL(null, {
            enableLoadingSubstates: true
        });

        if (self.moduleDefinitions[moduleName].contextPath) {
            routeRegConfig.path = '/' +
                self.moduleDefinitions[moduleName].contextPath;
        }

        function generateDSL() {
            this.route("application", { path: "/", overrideNameAssertion: true }, function () {
                this.route(moduleName, routeRegConfig, function () {
                    callback.call(this);
                });
            });
        }

        generateDSL.call(dsl);

        getOwner(this).lookup('router:main').router.map(dsl.generate());
    },
    /**
     * Loads the module specific routes into the Router.
     **/
    loadRoutesFromModule(moduleName) {
        moduleName = this._getModuleName(moduleName);
        var mainRouter, routeMap = require(moduleName + '/route-map')['default'];
        //this.application.Router.mapDynamically(routeMap);
        mainRouter = getOwner(this).lookup('router:main').router;
        if (mainRouter === undefined) {
            this._mapOnStartupQueue.push({
                moduleName : moduleName,
                routeMap : routeMap
            });
        } else {
            this._mapDynamically(moduleName, routeMap);
        }
    },

    /**
     * Load the module specific liquid fire transition.js
     **/
    loadTransitionsFromModule(moduleName) {
        try {
            var transitionHandler = require(moduleName + '/transitions')['default'];
            moduleName = this._getModuleName(moduleName);
            this._mapTransitions(moduleName, transitionHandler);
        } catch (err) {
            Ember.Logger.debug(err.message);
        }
    },

    /**
     * Map liquid fire transitions
     **/
    _mapTransitions(moduleName, handler) {
        var functionsToWrap = ["fromRoute", "toRoute", "withinRoute"], i, functionName,
        liquidFire = getOwner(this).lookup('service:liquid-fire-transitions'),
        LiquidFireDsl = require('liquid-fire/dsl').default,
        dsl = new LiquidFireDsl(liquidFire),
        generateWrapper = function (functionName, moduleName) {
            return function (route) {
                route = moduleName + '.' + route;
                return this[functionName](route);
            };
        };
        for (i = 0; i < functionsToWrap.length; i++) {
            functionName = functionsToWrap[i];
            dsl[functionName + 'Tmp'] = dsl[functionName];
            dsl[functionName] = generateWrapper(functionName + 'Tmp', moduleName);
        }
        handler.apply(dsl);
    },

    getModule(moduleName) {
        moduleName = this._getModuleName(moduleName);
        return require(moduleName + '/app');
    },

    getModuleDefinition(moduleName) {
        moduleName = this._getModuleName(moduleName);
        if (moduleName === undefined) {
            return this.moduleDefinitions;
        } else if (this.moduleDefinitions[moduleName] !== undefined) {
            return this.moduleDefinitions[moduleName];
        } else {
            throw new Error('Module ' + moduleName + ' not found');
        }
    },

    /**
     * Returns true if the module is already loaded.
     **/
    isModuleLoaded(moduleName) {
        moduleName = this._getModuleName(moduleName);
        return ((this.moduleDefinitions[moduleName] !== undefined &&
            this.moduleDefinitions[moduleName].loaded === true) ||
            this.application.name === moduleName);
    },

    getCurrentModuleNameFromRoute(route) {
        try {
            var moduleName = route.split('.')[0];
            this.getModuleDefinition(moduleName);
            return moduleName;
        }
        catch (e) {
            return null;
        }
    },

    getModuleNameFromURL(url) {
        var moduleName = this._getModuleName(url.split('/')[1]);
        return this.getCurrentModuleNameFromRoute(moduleName);
    },

    getCurrentModuleNameFromActiveTransition() {
        var router = getOwner(this).lookup('router:main').router, latestHandler;
        if (!!router.activeTransition) {
            latestHandler = router.activeTransition.handlerInfos[router.activeTransition.handlerInfos.length - 1];
            return this.getCurrentModuleNameFromRoute(latestHandler.name);
        }
        return null;
    },

    isSubModulePattern(namedRoute) {
        var moduleName = namedRoute.split('.')[0];
        moduleName = this._getModuleName(moduleName);
        if (this.moduleDefinitions[moduleName] !== undefined) {
            return true;
        }

        return false;
    }
});
