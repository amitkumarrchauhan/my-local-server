import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
    handle: function (progressUpdate) {
        getOwner(this).lookup('controller:application').set('progressUpdate', progressUpdate.body.message);
    }
});
