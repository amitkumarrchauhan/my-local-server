import Ember from 'ember';

export default Ember.Service.extend({
    sessionStorageKey: 'restrictedResource',
    flag: 0,
    resourceTracker: Ember.Object.create({
        myResources: Ember.Object.create(),
        resourcesUsedByOtherWindows: Ember.Object.create(),
        myActiveResources: Ember.Object.create()
    }),
    init: function () {
        sessionStorage.singleWindowRestrictorKey = this.get('uuid');
        this._initCrosstabCommunication();
        this._queryExistingUsage();
        this._super();
    },
    _queryExistingUsage() {
        crosstab.broadcast('sendResourcesInUse');
    },
    generateId(resource) {
        var params = resource.paramsFor(resource.routeName),
            keys = Object.keys(params).sort(), id = resource.routeName.replace(/\./g, '#'), i;
        /*
        If the route has generateResourceId method implemented,
        Then that method will used to generate resource id
        */
        if (resource.generateResourceId) {
            return resource.generateResourceId();
        }
        for (i = 0; i < keys.length; i++) {
            id += '#' + params[keys[i]].replace(/\./g, '#');
        }
        return id;
    },
    _initCrosstabCommunication() {
        crosstab.on('sendResourcesInUse', function (message) {
            if (message.origin === crosstab.id) {
                return;
            } else {
                crosstab.broadcast('resourcesInUse', JSON.stringify(this.get('resourceTracker.myActiveResources')));
            }
        }.bind(this));

        crosstab.on('resourcesInUse', function (message) {
            if (message.origin === crosstab.id) {
                return;
            } else {
                Ember.merge(this.get('resourceTracker.resourcesUsedByOtherWindows'), JSON.parse(message.data));
                this.incrementProperty('flag');
            }
        }.bind(this));

        crosstab.on('holdResource', function (message) {
            if (message.origin === crosstab.id) {
                return;
            } else {
                this.set('resourceTracker.resourcesUsedByOtherWindows' + message.data, {
                    tab: message.origin
                });
                this.incrementProperty('flag');
            }
        }.bind(this));

        crosstab.on('releaseResource', function (message) {
            if (message.origin === crosstab.id) {
                return;
            } else {
                this.set('resourceTracker.resourcesUsedByOtherWindows.' + message.data, null);
                this.decrementProperty('flag');
            }
        }.bind(this));

        // when the user closes the window, release the resources
        crosstab.on('tabClosed', function (tab) {
            // If the closed tab is not the current tab, return
            if (tab.id !== crosstab.id) {
                return;
            }
            var blockedResources = this.get('resourceTracker.myActiveResources'), k;
            for (k in blockedResources) {
                if (blockedResources.hasOwnProperty(k)) {
                    crosstab.broadcast('releaseResource', k);
                }
            }
        }.bind(this));
    },
    addResource(resource) {
        var _service = this, resourceId = this.generateId(resource);
        this.set('resourceTracker.myResources.' + resourceId, resource);
        resource.on('activate', function () {
            var resourceId = _service.generateId(this), resource = _service.get('resourceTracker.resourcesUsedByOtherWindows.' + resourceId);
            if (resource === null || resource === undefined) {
                _service.set('resourceTracker.myActiveResources.' + resourceId, {
                    tab: crosstab.id
                });

                crosstab.broadcast('holdResource', resourceId);
            }
        }.bind(resource));
        resource.on('deactivate', function () {
            var resourceId = _service.generateId(this), resource = _service.get('resourceTracker.resourcesUsedByOtherWindows.' + resourceId);
            if (resource === null || resource === undefined) {
                _service.set('resourceTracker.myActiveResources.' + resourceId, null);

                crosstab.broadcast('releaseResource', resourceId);
            }
        }.bind(resource));
    }
});
