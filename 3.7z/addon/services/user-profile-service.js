import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Service.extend({
    init: function () {
        this._super.apply(this, arguments);
        this._restoreUserProfile();
    },

    initUserProfile: function (userProfile) {
        localStorage.userProfile = JSON.stringify(userProfile);
        // Hack - Since store is not registered when the authenticator is initialized
        Ember.run.next(this, function () {
            var store = getOwner(this).lookup('service:store');
            this.set('userProfile', store.push(store.normalize('user', userProfile)));
        });
    },

    /**
     * Clears the user profile from local storage
     */
    clearUserProfile: function () {
        this.userProfile = null;
        delete localStorage.userProfile;
    },

    /**
     * @private
     * Restores the config from the localStorage on browser refresh
     **/
    _restoreUserProfile: function () {
        if (localStorage.userProfile && localStorage.userProfile !== 'undefined') {
            this.initUserProfile(JSON.parse(localStorage.userProfile));
        }
    }
});
