import Ember from 'ember';
import Base from 'ember-simple-auth/authenticators/base';
import request from 'ember-ajax';
import HttpStatusCode from 'supdash-ui-core/utils/http-status-codes';
import AppConst from 'supdash-ui-core/utils/app-const';

export default Base.extend({
  hostURL: '',
  apiURL: '/cxf/sd',
  performanceLogger: Ember.inject.service(),
  userProfileService: Ember.inject.service(),
  coreModuleLoader: Ember.inject.service(),
  //wbUserPreference: Ember.inject.service(),
  //supPush: Ember.inject.service(),

  getErrorMessageFromResponse: function(response) {
    try {
      var errorJson = JSON.parse(response.responseText).errors;
      return errorJson[0].code + " - " + errorJson[0].title;
    } catch (e) {
      return "Unknown error occured!!";
    }
  },
  restore(data) {
    return new Ember.RSVP.Promise(function(resolve, reject) {
      var appToken;
      if (data === undefined) {
        reject();
      }
      appToken = data[AppConst.APP_TOKEN_KEY];
      Ember.$.ajax({
        url: this.hostURL + this.apiURL + '/validate',
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        type: 'GET',
        context: this,
        beforeSend: function(jqXHR) {
          jqXHR.setRequestHeader(AppConst.APP_TOKEN_NAME, appToken);
        },
        success: function(response) {
          this.initDownStreamServices(response);
          resolve(response);
        }.bind(this),
        error: function(response) {
          var statuscode = response.status,
            errorMsg;
          if (statuscode === HttpStatusCode.UNAUTHORIZED) {
            errorMsg = "Session Expired";
          } else if (statuscode === HttpStatusCode.CONFLICT) {
            errorMsg = "Cannot allow concurrent login";
          } else {
            errorMsg = this.getErrorMessageFromResponse(response);
          }
          sessionStorage.loginErrorMessage = errorMsg;
          reject(new Error(errorMsg));
        }.bind(this)
      });
    }.bind(this));
  },
  initDownStreamServices(data) {
    if (data.performanceLogging instanceof Object) {
      this.get('performanceLogger').initLogger(data.performanceLogging);
    }
    if (data.userProfile instanceof Object) {
      this.get('userProfileService').initUserProfile(data.userProfile);
    }
    if (data.userPreferenceMap) {
      //this.get('wbUserPreference').initUserPreferences(data.userPreferenceMap);
    }
    //this.get('supPush').initPushService(this.get('coreModuleLoader.appConfig.corePushConfig'), data.userProfile);
  },
  authenticate(credential) {
    var credentialData = {
      username: credential.identification,
      password: credential.password
    };
    return new Ember.RSVP.Promise(function(resolve, reject) {
      Ember.$.ajax({
        url: this.hostURL + this.apiURL + '/login',
        dataType: 'json',
        data: JSON.stringify(credentialData),
        contentType: "application/json; charset=utf-8",
        type: 'POST',
        context: this,
        success: function(response) {
          this.initDownStreamServices(response);
          var tokenObj = {};
          tokenObj[AppConst.APP_TOKEN_KEY] = response[AppConst.APP_TOKEN_KEY];

          resolve(tokenObj);
        }.bind(this),
        error: function(response) {
          var statuscode = response.status,
            error;
          if (statuscode === HttpStatusCode.UNAUTHORIZED) {
            error = new Error("Invalid credentials");
          } else if (statuscode === HttpStatusCode.CONFLICT) {
            error = new Error("Cannot allow concurrent login");
          } else {
            error = new Error(this.getErrorMessageFromResponse(response));
          }
          error.supress = true;
          reject(error);
        }.bind(this)
      });
    }.bind(this));
  },
  invalidate() {
    delete localStorage.userProfile;
    return new Ember.RSVP.Promise((resolve) => {
      request(this.hostURL + this.apiURL + '/invalidate').then(function() {
        resolve();
      }, function() {
        resolve();
      });
    });
  }
});
