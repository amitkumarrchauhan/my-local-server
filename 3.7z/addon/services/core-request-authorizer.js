import BaseAuthorizer from 'ember-simple-auth/authorizers/base';
import Ember from 'ember';
import AppConst from 'supdash-ui-core/utils/app-const';

export default BaseAuthorizer.extend({
    isServiceFactory: true,
    requestID: 1,
    getNextRequestId: function () {
        Ember.run.next(this, function () {
            this.incrementProperty('requestID');
        });
        return this.get('requestID');
    },
    authorize: function (jqXHR) {
        if (this.get('session.isAuthenticated') === true) {
            this.set('lastRequestTime', new Date().getTime());
            jqXHR.setRequestHeader(AppConst.APP_TOKEN_NAME, this.get('session.secure.'+ AppConst.APP_TOKEN_KEY));
            jqXHR.setRequestHeader(AppConst.APP_REQUEST_ID, this.get('requestID'));
            this.incrementProperty('requestID');

            // In iframe mode whenever a request is sent, extend 1.0 session
            if (sessionStorage.iframeMode === "true" && window.parentIFrame != null) {
                window.parentIFrame.sendMessage('touchSession');
            }
        }
    }
});
