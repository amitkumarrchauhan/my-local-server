import Ember from 'ember';
import ProgressIndicatorMixin from 'supdash-ui-core/mixins/progress-indicator';
/*
* Purpose this mixin is to show and hide progress indicator when route is changed.
*/
export default Ember.Mixin.create(ProgressIndicatorMixin, {
    actions: {
        loading() {
            this.showLoadingIndicator();
            return false;
        },

        didTransition() {
            this.hideLoadingIndicator();
            return false;
        }
    }
});
