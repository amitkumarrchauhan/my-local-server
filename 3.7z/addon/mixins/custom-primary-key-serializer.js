import Ember from 'ember';

/**
* Purpose: to normalize Id base on primaryKey attribute of the serializer which extends this mixin
*/
export default Ember.Mixin.create({
    normalizeId: function (hash) {
        var primaryKey = Ember.get(this, 'primaryKey');
        if (primaryKey === 'id') {
            return;
        }
        hash.id = hash[primaryKey];
    }
});
