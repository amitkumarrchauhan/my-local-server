import Ember from 'ember';
const { getOwner } = Ember;
/**
* Purpose: this is to show progress indicator.
*/
export default Ember.Mixin.create({
    isLoadingIndicatorSupported: true,
    showingLoadingIndicator: false,
    hideLoadingIndicator() {
        var applicationController = getOwner(this).lookup('controller:application');
        if (applicationController.get('showingLoadingIndicator') === true) {
            applicationController.toggleProperty('showingLoadingIndicator');
            if (sessionStorage.iframeMode === "true" && window.parentIFrame != null) {
                window.parentIFrame.sendMessage('hideLoadingIndicator');
                return;
            }
            applicationController.set('willLoadingIndicatorHide', true);
            Ember.run.later(function () {
                applicationController.set('wbRouteLoading', false);
                applicationController.set('willLoadingIndicatorHide', false);
            }.bind(this), 500);
        }

        if (applicationController.get('progressUpdate') != null) {
            applicationController.set('progressUpdate', null);
        }
    },
    showLoadingIndicator() {
        var applicationController = getOwner(this).lookup('controller:application');
        if (applicationController.get('showingLoadingIndicator') !== true) {
            applicationController.toggleProperty('showingLoadingIndicator');
            if (sessionStorage.iframeMode === "true" && window.parentIFrame != null) {
                window.parentIFrame.sendMessage('showLoadingIndicator');
                return;
            }
            applicationController.set('wbRouteLoading', true);
        }
    }
});
