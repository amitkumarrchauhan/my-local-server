import Ember from 'ember';

/**
* Purpose: for restricting to single window...though needs to be checked how it works??
*/
export default Ember.Mixin.create({
    singleWindowRestrictionManager: Ember.inject.service(),
    flag: Ember.computed.alias('singleWindowRestrictionManager.flag'),
    resourceId: Ember.computed({
        get() {
            return this.get('singleWindowRestrictionManager').generateId(this);
        }
    }),
    isInUseObserver: Ember.observer('flag', function () {
        var service = this.get('singleWindowRestrictionManager'),
            resource = service.get('resourceTracker.resourcesUsedByOtherWindows.' + this.get('resourceId')), isInUse;
        if (resource !== null && resource !== undefined) {
            isInUse = true;
        } else {
            isInUse = false;
        }
        this.set('lockedByAnotherTab', isInUse);
        if (this.controller !== undefined) {
            this.controller.set('lockedByAnotherTab', isInUse);
        }
    }),
    init() {
        this._super.apply(this, arguments);
        Ember.run.next(function () {
            this.get('singleWindowRestrictionManager').addResource(this);
        }.bind(this));
    },
    setupController: function (controller) {
        controller.set('lockedByAnotherTab', this.get('lockedByAnotherTab'));
        this._super.apply(this, arguments);
    }
});
