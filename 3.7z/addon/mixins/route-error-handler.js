import Ember from 'ember';
/**
* Purpose: This is to show user friendly errors, This needs to be extended.
*/
export default Ember.Mixin.create({
  actions: {
    error(error) {
      if (this.get('isLoadingIndicatorSupported') === true) {
        this.hideLoadingIndicator();
      }

      if (!!error && error.status === 404) {
        this.mdFlashMessages.success('Service Not Found');
      } else if (!!error && error.status === 500) {
        this.mdFlashMessages.success('Service Failed due to Server Error');
      } else if (!!error && error.status === 401) {
        this.mdFlashMessages.success('Not Authorized');
      } else {
        this.mdFlashMessages.success('An exception has occured');
      }

      Ember.Logger.error(error.stack);

      error.errorHandled = true;

      return false;
    }
  }
});
