import Ember from 'ember';
/*
* Purpose: ??
*/
export default Ember.Mixin.create({
    queryFixtures (records, query) {
        var searchValue = query.searchValue.toLowerCase();
        return records.filter(function (record) {
            for (var key in record) {
                let currentValue = record[key];
                if (typeof currentValue === "string") {
                    if (currentValue.toLowerCase().indexOf(searchValue) > -1) {
                        return true;
                    }
                }
            }
            return false;
        });
    }
});
