import Ember from 'ember';

/**
* Purpose: This is to scroll to top of the page loaded by the new route.
*/
export default Ember.Mixin.create({
    actions: {
        didTransition() {
            if (sessionStorage.iframeMode === "true" && window.parentIFrame != null) {
                window.parentIFrame.sendMessage('scrollToTop');
            } else {
                if (Ember.$('#content-placeholder').length > 0) {
                    Ember.$('#content-placeholder').get('0').scrollTop = 0;
                }
            }

            this._super.apply(this, arguments);
            return true;
        }
    }
});
