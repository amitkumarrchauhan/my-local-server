import Ember from 'ember';
import ProgressIndicatorMixin from 'supdash-ui-core/mixins/progress-indicator';

/**
* Purpose: to show the progress indicator when a model is saved...this needs to be extended by that
* specific model
*/
export default Ember.Mixin.create(ProgressIndicatorMixin, {
    save() {
        this.showLoadingIndicator();
        return this._super().then(function (data) {
            this.hideLoadingIndicator();
            return data;
        }.bind(this)).catch(function (error) {
            this.hideLoadingIndicator();
            throw error;
        }.bind(this));
    },
    reload() {
        this.showLoadingIndicator();
        return this._super().then(function (data) {
            this.hideLoadingIndicator();
            return data;
        }.bind(this)).catch(function (error) {
            this.hideLoadingIndicator();
            throw error;
        }.bind(this));
    }
});
