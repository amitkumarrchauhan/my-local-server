import Ember from 'ember';

/**
* Purpose: to add dirty save aware feature this needs to be extended in the route
*/
export default Ember.Mixin.create({

    initializeNewPageFlag: function () {
        this.set('newPage', true);
    }.on('activate'),

    actions: {
        willTransition (transition) {
            var isExitingRoute = this._isNewRouteSameAsPrevious(transition), isDirty = this.isModelDirty(), promise;
            if (!isExitingRoute && this.get('newPage') === true && isDirty) {
                transition.abort();
                this.set('newPage', false);
                if (window.confirm('You have unsaved changes, Do you want to save ?')) {
                    promise = this.saveModel();
                    if (promise) {
                        promise.then(function () {
                            transition.retry();
                        }.bind(this), function () {
                            transition.retry();
                        }.bind(this));
                    } else {
                        transition.retry();
                    }
                } else {
                    transition.retry();
                }
            }
        }
    },

    _isNewRouteSameAsPrevious (transition) {
        return this.routeName === transition.targetName;
    },

    saveModel () {
        Ember.Logger.error('This route is dirty check aware, make sure you implement saveModel method in your route');
    },

    isModelDirty () {
        Ember.Logger.error('This route is dirty check aware, make sure you implement isModelDirty method in your route');
        return false;
    }
});
