import DS from 'ember-data';
import CustomPrimaryKeySerializer from 'supdash-ui-core/mixins/custom-primary-key-serializer';

export default DS.RESTSerializer.extend(CustomPrimaryKeySerializer, {
    primaryKey : 'psId'
});
