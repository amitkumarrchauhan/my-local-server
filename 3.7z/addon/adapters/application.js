import DS from 'ember-data';
import Ember from 'ember';
const { getOwner } = Ember;

export default DS.RESTAdapter.extend({
    namespace: 'api',
    buildURL (modelName) {
        var url, model, applicationName,
            currentRoute, currentRouteName, router = getOwner(this).lookup('router:main');
        url = this._super.apply(this, arguments);
        model = this.store.modelFor(modelName);
        applicationName = getOwner(this).lookup('application:main').modulePrefix;

        //Try to get the serviceURL from the activeTransition in router
        if (router !== undefined) {

            router = router.router;

            try {
                currentRouteName = router.activeTransition.handlerInfos[router.activeTransition.resolveIndex].name;
                if (currentRouteName !== null && currentRouteName !== undefined) {
                    currentRoute = getOwner(this).lookup('route:' + currentRouteName.replace('.index', ''));
                    if (currentRoute != null && currentRoute.get('serviceUrl') != null) {
                        return currentRoute.get('serviceUrl');
                    }
                }
            } catch (e) {
                Ember.Logger.debug(e);
            }

            //Try to see if the current route has serviceURL if no active transition is available in router.
            // ServiceUrl from current route will be taken only if there is no activeTransition. This handles model.reload() and save() calls within route
            // This is primarily done for handling the save in fsPage
            try {
                currentRouteName = getOwner(this).lookup('controller:application').get('currentRouteName');
                currentRoute = getOwner(this).lookup('route:' + currentRouteName.replace('.index', ''));
                if (router.activeTransition === null) {
                    if (currentRoute.get('serviceUrl') !== undefined && currentRouteName.toLowerCase().indexOf(modelName.replace(new RegExp('-', 'g'), '').toLowerCase()) !== -1) {
                        return currentRoute.get('serviceUrl');
                    }
                }
            } catch (e) {
                Ember.Logger.debug(e);
            }
        }

        return url;
    },
    ajax (url, type, options) {
        if (options !== undefined && options.data !== undefined && options.data.serviceUrl !== undefined) {
            url = options.data.serviceUrl;
            delete options.data.serviceUrl;
        }
        return this._super(url, type, options);
    }
});
