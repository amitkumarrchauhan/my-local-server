import Ember from 'ember';
const { getOwner } = Ember;

var Router = Ember.Router.extend({
  hideSecondaryNav: Ember.on('didTransition', function() {
    try {
      var container = getOwner(this),
        applicationController = container.lookup('controller:application'),
        dockPaneController = container.lookup('controller:dockPane'),
        currentRoute = container.lookup('route:' + applicationController.get('currentRouteName').replace('.index', '')),
        hideSecondaryNav = currentRoute.get('hideSecondaryNav'),
        showDockPane = currentRoute.get('showDockPane'),
        willplaybackRoutes,
        canBeDocked = currentRoute.get('canBeDocked'),
        disablePrimaryNav = currentRoute.get('disablePrimaryNav'),
        disableTopBar = currentRoute.get('disableTopBar');

      if (showDockPane === true) {
        applicationController.set('showDockPane', true);
        //applicationController.set('hideSecondaryNav', true);
        return;
      } else {
        applicationController.set('showDockPane', false);
      }
      if (hideSecondaryNav === true) {
        applicationController.set('hideSecondaryNav', true);
      } else {
        applicationController.set('hideSecondaryNav', false);
      }

      if (disablePrimaryNav === true) {
        applicationController.set('disablePrimaryNav', true);
      } else {
        applicationController.set('disablePrimaryNav', false);
      }

      if (disableTopBar === true) {
        applicationController.set('disableTopBar', true);
      } else {
        applicationController.set('disableTopBar', false);
      }

      willplaybackRoutes = currentRoute.get('willPlaybackRoues');
      if (Boolean(willplaybackRoutes) === false && Boolean(canBeDocked) === false) {
        dockPaneController.send('clearDockWithoutRedirect');
      }
    } catch (e) {
      console.log(e.message);
    }
  }),

  hideSecondaryTopBar: Ember.on('didTransition', function() {
    try {
      var container = getOwner(this),
        applicationController = container.lookup('controller:application'),
        currentRoute = container.lookup('route:' + applicationController.get('currentRouteName').replace('.index', '')),
        hideSecondaryTopBar = currentRoute.get('hideSecondaryTopBar');

      if (hideSecondaryTopBar === true) {
        applicationController.set('hideSecondaryTopBar', true);
        applicationController.set('secondaryTopBarHiddenCls', 'base-top-bar-secondary-hidden');
      }

    } catch (exception) {
      console.log(exception.message);
    }
  })
});

Router.map(function() {
  this.route('pageUnauthorized', {
    path: '/unauthorized'
  });
  this.route('pageNotFound', {
    path: '/not-found'
  });
  this.route('error', {
    path: '/*bad'
  });
  this.route('login');
});

export default Router;
