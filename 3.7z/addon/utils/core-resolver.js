/**
 * Custom resolver which is aware of modularization.
 **/
import Resolver from 'ember-resolver';
import Ember from 'ember';

var coreResolver = Resolver.extend({
    moduleNameLookupPatterns: Ember.computed(function () {
        return Ember.A([
          this.podBasedModuleName,
          this.podBasedComponentsInSubdir,
          this.mainModuleName,
          this.defaultModuleName,
          this.wbSubModuleName
        ]);
    }),

    /**
     * Checks whether the required module resides in submodule.
     **/
    wbSubModuleName (parsedName) {

        // If the moduleLoader is not available, it means that the application is booting up.
        // No need to intervene at this time.
        if (this.moduleLoader === undefined ||
            this.moduleLoader.isLoaded !== true) {
            return;
        }
        var parsedNameParts = parsedName.fullNameWithoutType.split('/'),
            moduleLoader = this.moduleLoader, resolvedPath;
        if (moduleLoader.isSubModulePattern(parsedNameParts[0]) === true) {
            if (parsedName.fullNameWithoutType.indexOf('/') !== -1) {
                try {
                    resolvedPath = parsedName.fullNameWithoutType.replace('/', '/' + this.pluralize(parsedName.type) + '/');
                    require(resolvedPath);
                    // Replaces ONLY the first occurence of '/' with '/(type of required module)+'s'/'.
                    return resolvedPath;
                } catch (e) {
                    resolvedPath = parsedNameParts[0] + '/' + this.pluralize(parsedName.type) + '/' + parsedName.fullNameWithoutType;
                    return resolvedPath;
                }
            } else {
                return parsedName.fullNameWithoutType + '/' + this.pluralize(parsedName.type) + '/' + parsedName.fullNameWithoutType;
            }
        }
    },

    _searchInCurrentApp(parsedName) {
        var path = parsedName.prefix + '/' + this.pluralize(parsedName.type) + '/' + parsedName.fullNameWithoutType, target;
        try {
            target = require(path)['default'];
            target = this._injectModuleName(target, parsedName.prefix);
            return target;
        } catch (err) {
            return null;
        }
    },

    _injectModuleName(target, moduleName) {
        try {
            if (target !== null && target.moduleName === undefined) {
                target.reopenClass({
                    moduleName: moduleName
                });
            }
        } catch (e) {
            //
        }
        return target;
    },

    _searchInAllLoadedModules(parsedName) {
        var moduleDependencies = this.moduleLoader.getModuleDefinition(), path, target, k;
        for (k in moduleDependencies) {
            try {
                if (moduleDependencies[k].loaded === true) {
                    path = k + '/' + this.pluralize(parsedName.type) + '/' + parsedName.fullNameWithoutType;
                    target = require(path)['default'];
                    target = this._injectModuleName(target, k);
                    return target;
                }
            } catch (err) {
                // can be ignored.
            }
        }
        return null;
    },

    resolveRoute (parsedName) {
        var route = this.resolveOther(parsedName), routeNameParts, routeName;

        // If the route is a form service(fsPage and fsForm) route, resolve it from the namespace of the current app
        if (route === undefined) {
            routeNameParts = parsedName.fullNameWithoutType.split('/');
            routeName = routeNameParts[routeNameParts.length - 1];

            if (routeName === 'fs-page' || routeName === 'fs-form' || routeName === 'fs-iframe') {
                route = require(parsedName.prefix + '/routes' + '/' + routeName).default;
            }
        }

        return route;
    },

    resolveComponent (parsedName) {
        var component = this.resolveOther(parsedName);
        if (component != null) {
            return component;
        } else {
            return this._searchInAllLoadedModules(parsedName);
        }
    },

    resolveSerializer (parsedName) {
        var serializer = this._searchInCurrentApp(parsedName);
        if (serializer === null) {
            serializer = this._searchInAllLoadedModules(parsedName);
        }
        return serializer;
    },

    resolveAdapter(parsedName) {
        var adapter = this._searchInCurrentApp(parsedName);
        if (adapter === null) {
            adapter = this._searchInAllLoadedModules(parsedName);
        }
        return adapter;
    },

    resolveModel (parsedName) {
        var model = this._searchInCurrentApp(parsedName);
        if (model === null) {
            model = this._searchInAllLoadedModules(parsedName);
        }
        return model;
    },

    resolveTemplate (parsedName) {
        var template = this.resolveOther(parsedName);

        if (!template) {
            return this._searchInAllLoadedModules(parsedName);
        } else {
            return template;
        }
    },

    resolveController (parsedName) {
        var controller = this._searchInCurrentApp(parsedName);
        if (controller === null) {
            controller = this._searchInAllLoadedModules(parsedName);
        }
        return controller;
    },

    resolveTransform (parsedName) {
        var transform = this._searchInCurrentApp(parsedName);
        if (transform === null) {
            transform = this._searchInAllLoadedModules(parsedName);
        }
        return transform;
    }
});

export default coreResolver;
