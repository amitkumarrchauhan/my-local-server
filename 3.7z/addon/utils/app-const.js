export default {
    APP_TOKEN_KEY: 'wbToken',
    APP_TOKEN_NAME: 'APP-TOKEN',
    APP_REQUEST_ID: 'APP-REQUEST-ID',
};
