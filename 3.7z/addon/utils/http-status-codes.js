export default {
    OK : 200,
    UNAUTHORIZED: 401,
    CONFLICT: 409
};
