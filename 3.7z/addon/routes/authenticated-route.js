import Ember from 'ember';
import AuthenticatedRouteMixin from 'ember-simple-auth/mixins/authenticated-route-mixin';
import RouteErrorHandlerMixin from 'supdash-ui-core/mixins/route-error-handler';

export default Ember.Route.extend(AuthenticatedRouteMixin, RouteErrorHandlerMixin);
