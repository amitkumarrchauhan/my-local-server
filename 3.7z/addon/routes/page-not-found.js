import Ember from 'ember';
import RouteProgressIndicatorMixin from 'supdash-ui-core/mixins/route-progress-indicator';

export default Ember.Route.extend(RouteProgressIndicatorMixin, {
    hideSecondaryNav: true,
    actions() {
        this.hideLoadingIndicator();
    }
});
