import ApplicationAdapter from 'supdash-ui-core/adapters/application';

export default ApplicationAdapter.extend({
});
