export { default } from 'supdash-ui-core/routes/page-not-found';
