export { default } from 'supdash-ui-core/routes/page-unauthorized';
