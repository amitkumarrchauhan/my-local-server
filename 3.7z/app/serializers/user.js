export { default } from 'supdash-ui-core/serializers/user';
