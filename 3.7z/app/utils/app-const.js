export { default } from 'supdash-ui-core/utils/app-const';
