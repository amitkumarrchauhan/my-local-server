export { default } from 'supdash-ui-core/services/user-profile-service';
