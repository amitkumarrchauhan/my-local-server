export { default } from 'supdash-ui-core/services/core-authentication';
