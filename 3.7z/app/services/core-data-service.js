export { default } from 'supdash-ui-core/services/core-data-service';
