export { default } from 'supdash-ui-core/services/performance-logger';
