export { default } from 'supdash-ui-core/models/user';
