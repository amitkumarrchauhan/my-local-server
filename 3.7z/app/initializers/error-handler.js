export { default, initialize } from 'supdash-ui-core/initializers/error-handler';
