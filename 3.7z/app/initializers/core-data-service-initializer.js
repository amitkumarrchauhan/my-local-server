export { default, initialize } from 'supdash-ui-core/initializers/core-data-service-initializer';
