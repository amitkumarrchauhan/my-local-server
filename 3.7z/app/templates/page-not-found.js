export { default } from 'supdash-ui-core/templates/page-not-found';
