import Resolver from 'supdash-ui-core/utils/core-resolver';

export default Resolver;
