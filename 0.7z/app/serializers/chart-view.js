import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  attrs: {
    chartConfig: {
      embedded: 'always'
    },
    filter: {
      embedded: 'always'
    },
    chartData: {
      embedded: 'always'
    }
  },

  normalizeResponse(store, primaryModelClass, payload, id, requestType) {
    payload.chartView.chartData.chartSeries = this.prepareChartSeries(payload.chartView.chartData.chartSeries);
    payload.chartView.id = Math.random() * 1010000;
    payload.chartView.chartData.id = Math.random() * 1010000;
    if (payload.chartView.chartData.hasOwnProperty('chartTitle') && Ember.isEmpty(payload.chartView.chartData.chartTitle)) {
      delete payload.chartView.chartData.chartTitle;
    }
    return this._super(store, primaryModelClass, payload, id, requestType);
  },

  prepareChartSeries(chartData) {
    var newChartSeries = [];
    var seriesCount = chartData.length;
    // var dummyObject = this.cloneObject(chartData[0]);
    // for(let i=seriesCount-1; i<=5;i++){
    //   dummyObject.name = 'blank_'+i;
    //   chartData.push(dummyObject);
    // };
    chartData.forEach(function(items /*, key*/ ) {
      items.dataItems.forEach(function(item /*, key*/ ) {
        item.name = items.name;
        item.ragColor = items.ragColor;
        item.seriesCount = seriesCount;
        newChartSeries.push(item);
      });
    });
    return newChartSeries;
  },

  cloneObject( /*data*/ ) {
    let id = Math.random() * 11999009;
    let obj = {
      "name": "",
      "ragColor": "",
      "dataItems": [{
        "id": id,
        "item": "",
        "actualValue": "",
        "displayValue": "",
        "color": ""
      }]
    };

    return obj;
  }
});
