import Ember from 'ember';

export default Ember.Mixin.create({
  mapAction(actionName) {
    /* setting this, is required for sending Action to parent route/controller STARTS*/
    var action = this.get(actionName) || actionName;
    if (action) {
      this[action] = action;
    }
    /* setting this, is required for sending Action to parent route/controller ENDS*/
  }
});
