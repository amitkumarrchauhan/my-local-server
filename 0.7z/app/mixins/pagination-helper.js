import Ember from 'ember';

export default Ember.Mixin.create({

  handleServerPagination() {
    if (this.serverPaging) {
      this.updateDefaultPageableObject();
      this.addDataSourceChangeEvent();
    }
  },

  handleServerPaginationElements() {
    if (this.serverPaging) {
      this.initializePagerComponentState();
      this.addEventHandlers();
    }
  },

  initializePagerComponentState() {
    this.pageSizeCombo = Ember.$('#' + this.gridId +' .k-dropdown select');
  },

  updateDefaultPageableObject() {
    let _this = this;

    this.defaultPageable.change = function(event) {
      _this.loadNewDataSet(event.index);
    };
  },

  loadNewDataSet(pageNumber) {
    let params = {};
    params[this.gridIdParamKey] = this.gridItemId;
    params.configRequired = false;
    params.currentPage = pageNumber;
    params.pageSize = this.get('pageSize');

    this.get('coreDataService').queryRecord('gridItem', params).then((gridItem) => {
      this.gridData = gridItem.get('gridData');
      this.set('data', this.gridData.data);
    });
  },

  addDataSourceChangeEvent() {
    let _this = this;

    this.gridConfig.dataSource.change = function( /*event*/ ) {
      if (_this.get('data')) {
        this._total = _this.get('totalRecords');
      }
    };
  },

  addEventHandlers() {
    this.pageSizeCombo.on('change', this.onPageSizeChange.bind(this));
  },

  onPageSizeChange() {
    this.set('pageSize', parseInt(this.pageSizeCombo.val()));
    this.loadNewDataSet(1);
  },

  willDestroy() {
    if (this.serverPaging) {
      this.pageSizeCombo.off('change');
    }
    console.log('remove all attached events for : ' + this.gridItemId);
  }
});
