import Ember from 'ember';
const {getOwner} = Ember;

export default Ember.Service.extend({
  pushTransitionInfo(transition) {
    let transitionStack = Ember.lookup.sessionStorage.getItem('transitionStack');

    if (!transitionStack) {
      transitionStack = '[]';
    }

    transitionStack = JSON.parse(transitionStack);

    var oldQueryParams = this.removeTransitionInfoIfExist(transitionStack, transition);

    transitionStack.pushObject({
      currentRoute: transition.targetName,
      queryParams: Object.keys(transition.queryParams).length === 0 ? (oldQueryParams ? oldQueryParams : {}) : transition.queryParams
    });

    Ember.lookup.sessionStorage.setItem('transitionStack', JSON.stringify(transitionStack));
  },

  removeTransitionInfoIfExist(transitionStack, transition) {
    for (let i = 0, len = transitionStack.length; i < len; i++) {
      let transitionInfo = transitionStack[i];

      if (transitionInfo.currentRoute === transition.targetName) {
        let oldTransitionInfo = transitionStack[i];
        transitionStack.removeAt(i);
        return oldTransitionInfo.queryParams;
      }
    }
  },

  getTransitionQueryParams(transition) {
    let transitionStack = Ember.lookup.sessionStorage.getItem('transitionStack');

    if (transitionStack) {
      transitionStack = JSON.parse(transitionStack);

      for (let i = 0; i < transitionStack.length; i++) {
        let transitionItem = transitionStack[i];

        if (transitionItem.currentRoute === transition.targetName) {
          return transitionItem.queryParams;
        }
      }
    }

    return {};
  },

  getCurrentRoute() {
    let owner = getOwner(this);
    let applicationController = owner.lookup('controller:application');
    let currentRoute = owner.lookup('route:' + applicationController.get('currentRouteName').replace('.index', ''));

    return currentRoute;
  },

  getPreviousRoute() {
    let transitionStack = Ember.lookup.sessionStorage.getItem('transitionStack');

    if (transitionStack) {
      transitionStack = JSON.parse(transitionStack);

      if (transitionStack[transitionStack.length - 2]) {
        var previousTranstion = transitionStack[transitionStack.length - 2];

        return previousTranstion.currentRoute;
      }
    }
  }
});
