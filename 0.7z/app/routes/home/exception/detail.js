import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  showModuleTitle: true,

  setupController(controller,model){
    let moduleName = model.dashboard;
    let chartFileter = 'SourceSystem;';
    let chartid= moduleName+'_DetailView_By_'+chartFileter;

    controller.setProperties({
      detailParams:{chartFileter:chartFileter,chartId:chartid,durationfilter:'1M',includeInDirectReports:true},
      modelNameForModule:'chartView'
    });
  },
});
