import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  model( /*params*/ ) {
    //return this.store.queryRecord('dashboardList',params);
  },

  setupController(controller /*, model*/ ) {
    let dataItems = [{
      "id": "MissedTrades",
      "title": "Missed Trades"
    }, {
      "id": "cancelamend",
      "title": "Cancel & Amend"
    }, {
      "id": "mismark",
      "title": "Mismarks"
    }, {
      "id": "latesignoff",
      "title": "Late Sign off for OMR,P&L,C&A and Risk Report"
    }, {
      "id": "haerdmargin",
      "title": "Hard Margin"
    }];

    controller.setProperties({
      viewDashConfig: {
        chartId: 'LM_View_By_Dashbaord',
        duration: '1M'
      },
      viewEmpConfig: {
        chartId: 'LM_View_By_Employee',
        duration: '1M'
      },
      viewSummaryConfig: {
        chartId: 'LM_View_By_Summary',
        duration: '1M',
        dashboardName: 'MissedTrade'
      },
      modelNameForModule: 'chartView',
      dataItems: dataItems,
      selectedItem: 'MissedTrades'
    });
  },

  actions: {
    chartClickAction(data) {
      let dashboard = data.category ? data.category.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase() : 'invaliddashboard';

      this.transitionTo('home.exception.detail', dashboard, {
        queryParams: {
          appTitle: data.category
        }
      });
    },

    clickAction(value) {
      this.controller.get('viewSummaryConfig').dashboardName = value;
      this.controller.set('viewSummaryConfig', this.controller.get('viewSummaryConfig'));
    }
  }
});
