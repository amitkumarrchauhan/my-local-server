import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,

  model () {
    //send request to get the initial state of the landing page like NO of context available
    // no of dashbaord types available
  },

  afterModel() {
    this.transitionTo('home.exception');
  },
  /**
   * Purpose: This hook has been used to render the secodary navigation menu items for the home.
   */
  renderTemplate() {
    this.render('sup-top-bar-secondary', {
      outlet: 'top-bar-secondary',
      into: 'application'
    });
  },
});
