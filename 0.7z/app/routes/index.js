import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
//import UserUtil from '../utils/user-util';

/**
 * Puprose: This is the first route which is called after user authentication is done.
 */
export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  /**
   * Purpose: This functio basically checks if user is authehticated or not, If authenticated then user is routed to
   * home otherwise login page displayed again.
   */
  beforeModel() {
    this._super.apply(this, arguments);

    if (!this.get('session').get('isAuthenticated')) {
      this.transitionTo('login');
    }

    this.transitionTo('home.exception');
  }
});
