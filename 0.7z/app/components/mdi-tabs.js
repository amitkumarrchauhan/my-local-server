import Ember from 'ember';
import mdTabs from 'ember-cli-materialize/components/md-tabs';
import MapActionMixin from '../mixins/map-action-mixin';

const { computed } = Ember;

export default mdTabs.extend(MapActionMixin, {
  onSelect: null,
  selected: null,

  sendActionOnChange: Ember.observer('selected', function() {
    if (this.onSelect) {
      this.sendAction(this.onSelect, this.selected);
    }
  }),

  actions: {
    onTabChange(selectedValue) {
      this.set('selected', selectedValue);
    }
  },

  init() {
    this._super();
    this.mapAction('onSelect');
  },

  _content: computed('content.[]', 'optionLabelPath', 'optionValuePath', function() {
    const labelPath = this.get('optionLabelPath');
    const valuePath = this.get('optionValuePath');

    return new Ember.A((this.get('content') || []).map(function (contentItem) {
      return {
        id: contentItem[valuePath],
        title: contentItem[labelPath],
        customClassNames: contentItem.customClassNames,
        maxDate: contentItem.maxDate
      };
    }));
  })
});
