import Ember from 'ember';
import mdInputDate from 'ember-cli-materialize/components/md-input-date';

export default mdInputDate.extend({
  classNames: ['mdi-date-field'],
  id: null,
  dateComponentSelector: '.datepicker',

  init() {
    this._super();
    var onDateChange = this.get('onDateChange');
    if (onDateChange) {
      this[onDateChange] = onDateChange;
    }
  },

  _setupPicker() {
    const datePickerOptions = this.getProperties('selectMonths', 'numberOfYears', 'min', 'max');
    datePickerOptions.selectYears = datePickerOptions.numberOfYears;

    this._onDateSet = evt => {
      if (evt.select) {
        var dateValue = this.formatDate(evt.select);

        this.set('value', dateValue);
        var onDateChange = this.get('onDateChange');
        if (onDateChange) {
          this.sendAction(onDateChange, dateValue);
        }
      }
    };

    let _this;
    if (this.get('durationFilter')) {
      _this = this.parentView;
    } else {
      _this = this;
    }

    _this.$(this.dateComponentSelector).pickadate(Ember.$.extend(datePickerOptions, {
      onSet: this._onDateSet
    }));
  },

  _teardownPicker() {
    let _this;
    if (this.get('durationFilter')) {
      _this = this.parentView;
    } else {
      _this = this;
    }

    const $pickadate = _this.$(this.dateComponentSelector) ? _this.$(this.dateComponentSelector).data('pickadate') : undefined;
    if ($pickadate) {
      $pickadate.stop();
    }
  },

  formatDate(selectedDate) {
    var formattedDate = moment(selectedDate).format('YYYY-MM-DD');

    return formattedDate;
  }
});
