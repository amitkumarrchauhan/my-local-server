import Ember from 'ember';
import mdRadios from 'ember-cli-materialize/components/md-radios';
import MapActionMixin from '../mixins/map-action-mixin';

const {get, A, computed} = Ember;

export default mdRadios.extend(MapActionMixin, {
  content: null,
  selection: null,
  optionValuePath: 'content',
  optionLabelPath: 'content',

  actions: {
    onChange(value) {
      if (!Ember.isEmpty(this.get('clickAction'))) {
        this.sendAction(this.clickAction, value);
      }
    }
  },

  init() {
    this._super(...arguments);
    this.mapAction('clickAction');
    if (this.get('selection') === null) {
      this.set('selection', new A([]));
    }
  },

  _valuePath: computed('optionValuePath', function() {
    const optionValuePath = get(this, 'optionValuePath');
    return optionValuePath.replace(/^content\.?/, '');
  }),

  _labelPath: computed('optionLabelPath', function() {
    const optionLabelPath = get(this, 'optionLabelPath');
    return optionLabelPath.replace(/^content\.?/, '');
  }),

  _content: computed('content.[]', '_valuePath', '_labelPath', function() {
    const valuePath = get(this, '_valuePath');
    const labelPath = get(this, '_labelPath');
    const content = get(this, 'content') || new A([]);

    if (valuePath && labelPath) {
      return new A(
        content.map(el => {
          return {
            value: get(el, valuePath),
            label: get(el, labelPath)
          };
        })
      );
    } else {
      //throw new Error('Please specify optionLabelPath and optionValuePath');
      return new A(
        content.map(el => {
          return {
            value: el,
            label: el
          };
        })
      );
    }
  })
});
