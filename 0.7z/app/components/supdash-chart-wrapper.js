import Ember from 'ember';
import layout from '../templates/components/supdash-chart-wrapper';

/**
 * Purpose: This is generic chart component, This componet is a wrapper for wb-new-barchart
 * All properites whihch will be required by wb-new-barchart are initialzed in the component
 * This also adds some dom element like header and action button on that header.
 */
export default Ember.Component.extend({
  layout: layout,
  chartClickAction: 'chartClickAction',
  chartConfig: {},
  chartDataSourceConfig: {},
  customAction: 'customAction',
  store: Ember.inject.service('store'),
  isContentLoaded: false,
  showRadioComponent: false,

  /**
   * Purpose: this is the action-hash/event-handler
   */
  actions: {
    onTabChange(duration) {
      this.serviceParams.duration = duration;
      //this.set('chartData',[]);
      this.get('store').queryRecord(this.modelNameForModule, this.serviceParams).then(function(a_data) {
        this.set('chartData', a_data.get('chartData').get('chartSeries'));
        this.set('chartTitleObj', a_data.get('chartData').get('chartTitle'));
      }.bind(this));
    },
    /**
     * Purpose: if user specifies some custom action then this event handler function will be called
     * and this function will make sure it sends that action to respective handler.
     */
    onCustomAction: function(a_customActionName) {
      this[a_customActionName] = a_customActionName;
      this.sendAction(a_customActionName);
    }
  },

  /**
   * Purpose: this function initializes all the properties which will be used by template component
   * like: toolbarItem, chartData, chartDataSourceConfig, chartConfig which are further used by
   * templates to render the component.
   */
  init: function() {
    var _this = this;
    this._super();
    this.modelNameForModule = this.get('modelNameForModule');
    this.serviceParams = this.get('serviceParams');
    let showRadioComponent = this.get('showRadioComponent');
    let serviceObjects = {
      chartServices: this.get('store').queryRecord(this.modelNameForModule, this.serviceParams)
    };
    if (showRadioComponent) {
      serviceObjects.radioServices = this.get('store').queryRecord('dashboardList', {});
    }
    Ember.RSVP.hash(serviceObjects).then(function(a_data) {
      let chartServiceData = a_data.chartServices;
      let radioServiceData = !Ember.isEmpty(a_data.radioServices) ? a_data.radioServices : {};
      _this.prepareChartAndDataConfig(chartServiceData);
      _this.setDurationFilter(chartServiceData.get('filter'));
      if (showRadioComponent && !Ember.isEmpty(radioServiceData)) {
        _this.setRadioFilter(radioServiceData);
      }
      _this.set('isContentLoaded', true);
    });
  },

  prepareChartAndDataConfig(a_data) {
    let graphConfig = a_data.get('chartConfig');
    let chartData = a_data.get('chartData');
    this.chartType = graphConfig.get('type');


    //For setting x-axis and y-axis
    let xAxis = graphConfig.get('xAxis');
    let yAxis = graphConfig.get('yAxis');
    let xAxisLabel = graphConfig.get('xAxisDisplayName') || xAxis;

    //group by config
    let groupBy = graphConfig.get('groupBy') || false;
    let isGrouping = groupBy ? true : false;
    let stackFlag = graphConfig.get('stack') || false;

    //Action handler
    let isAxisLabelClick = graphConfig.get('axisClick');
    let isSeriesClick = graphConfig.get('seriesClick');

    let chartConfigObj = {};
    chartConfigObj.theme = 'bootstrap';
    chartConfigObj.tooltip = {
      background: "black",
      visible: true,
      template: this.createToolTipTemplate.bind(this)
    };
    chartConfigObj.dataBound = this.updateDataForSeriesColor.bind(this);
    chartConfigObj.legend = this.createLegendConfig(this.chartType);
    chartConfigObj.categoryAxis = this.createCategoryConfig(this.chartType);
    chartConfigObj.series = this.createSeriesConfig(this.chartType, yAxis, stackFlag, xAxisLabel);
    chartConfigObj.valueAxis = this.createValueAxisConfig(this.chartType);
    chartConfigObj.pannable = {
      lock: (this.chartType.toUpperCase() === "BAR") ? 'x' : 'y'
    };

    if (isSeriesClick) {
      chartConfigObj.seriesClick = this.seriesClick.bind(this);
    }

    if (isAxisLabelClick) {
      chartConfigObj.axisLabelClick = this.axisLabelClick.bind(this);
    }

    let chartDataSourceConfigObj = {};
    chartDataSourceConfigObj.isGrouping = isGrouping;
    chartDataSourceConfigObj.groupField = groupBy;

    let title = graphConfig.get('title');
    let chartSeries = chartData.get('chartSeries');
    let totalTitle = chartData.get('chartTitle');
    let chartHeight = 340;

    if (!Ember.isEmpty(totalTitle) && totalTitle.get('value') > 0) {
      chartHeight = chartHeight - 76;
    }

    chartConfigObj.chartArea = {
      height: chartHeight
    };

    this.setDataAndConfig(chartSeries, chartConfigObj, chartDataSourceConfigObj, title, totalTitle);
  },

  setDurationFilter(a_data) {
    let filterItems = this.convertToJSON(a_data.get('durationFilter'));
    let selectedObject = filterItems.filterBy('selected', true)[0];
    this.setProperties({
      filterItems: filterItems,
      selected: selectedObject.id,
    });
  },

  setRadioFilter(a_data) {
    this.setProperties({
      selection: a_data.get('selected'),
      optionValuePath: 'id',
      optionLabelPath: 'title',
      content: a_data.get('dashboardItems'),
      clickAction: 'clickAction',
    });
  },

  setDataAndConfig(data, config, dataConfig, title, totalTitle) {
    this.setProperties({
      title: title,
      chartData: data,
      chartConfig: config,
      chartTitleObj: totalTitle,
      chartDataSourceConfig: dataConfig
    });
  },

  updateDataForSeriesColor(e) {
    let chart = e.sender;
    let chartSeries = chart.options.series;
    for (let i = 0; i < chartSeries.length; i++) {
      if (chartSeries[i] && !Ember.isEmpty(chartSeries[i].data)) {
        chartSeries[i].color = chartSeries[i].data[0].color;
      }

    }
  },

  createLegendConfig(type) {
    let legendconfig = {};
    type = type.toUpperCase();
    let position = (type === "COLUMN" || type === "DONUT") ? "right" : "bottom";
    legendconfig.position = position;
    //legendconfig.width = 500;
    legendconfig.labels = {
      color: '#4a4a4a',
      font: "11px Roboto-Regular",
      margin: {
        bottom: 10
      },
      template: "#: text.toUpperCase() #"
    };
    legendconfig.markers = {
      type: "circle",
      width: 7,
      margin: {
        bottom: 10
      },
    };

    if (type === "DONUT") {
      legendconfig.offsetX = -20;
    }
    if (type === "BAR") {
      legendconfig.offsetY = 10;
    }
    if (type === "COLUMN") {
      legendconfig.offsetX = 20;
      legendconfig.offsetY = -100;
    }
    return legendconfig;
  },

  creteChartTotalCountLabel(chartTitle) {
    let label = chartTitle.get('label');
    let value = chartTitle.get('value');
    let chartLabel = 'Total' + ' ' + label + ' ' + value;
    return chartLabel;
  },

  createValueAxisConfig(type) {
    let valueAxis = {
      labels: {
        visible: (type.toUpperCase() === "BAR"),
        color: "#888",
        format: "{0:n0}",
      },
      line: {
        visible: (type.toUpperCase() === "BAR"),
      }
    };
    return valueAxis;
  },

  createSeriesConfig(type, value, stack, categoryAxis) {
    let series = [];
    let seriesObj = {};
    let chartType = type.toUpperCase();
    seriesObj.field = value;
    seriesObj.type = type;
    seriesObj.border = {
      width: 0
    };
    seriesObj.colorField = "color";
    seriesObj.categoryField = categoryAxis;
    if (chartType === 'BAR' || chartType === 'COLUMN' || chartType === 'DONUT') {
      seriesObj.stack = stack;
      seriesObj.visual = this.setSeriesWidthToFixedVlaue.bind(this);
    }
    if (chartType === 'LINE') {
      seriesObj.style = "smooth";
    }
    if (chartType === 'DONUT') {
      seriesObj.holeSize = 80;
    }
    series.push(seriesObj);
    return series;
  },

  createCategoryConfig(type) {
    type = type.toUpperCase();
    let catAxis = {};
    catAxis.max = (type === "LINE") ? 10 : 5;
    catAxis.majorTicks = {
      width: 0
    };
    catAxis.labels = {
      font: "13px Roboto-Regular",
      color: '#424242',
      visual: this.createLabelItem.bind(this)
    };

    catAxis.majorGridLines = {
      visible: (type === "BAR") ? true : false
    };

    return catAxis;
  },

  createToolTipTemplate(a_data) {
    let w_tpl;
    //let w_toolTip = this.w_toolTip;
    let category = a_data.category ? a_data.category.toUpperCase() : 'Unknown';
    //let axis = a_data.dataItem[w_toolTip] ? a_data.dataItem[w_toolTip].toUpperCase() : 'Unknown';
    w_tpl = (category + ' : <span class="tooltip-number">' + a_data.dataItem['displayValue'] + '<span>');
    w_tpl = '<div class="tooltip-container">' + w_tpl + '</div>';

    return w_tpl;
  },

  setSeriesWidthToFixedVlaue(e) {
    let visual = e.createVisual();
    let chartType = this.chartType.toUpperCase();
    if (chartType === "BAR") {
      let rect = e.rect;
      let origin = rect.origin;
      //let center = rect.center();
      let bottomRight = rect.bottomRight();
      let geom = kendo.geometry;
      let Rect = geom.Rect;
      //let draw = kendo.drawing;
      //let Path = draw.Path;
      let color = e.dataItem ? e.dataItem.color : '';

      let lablesPadding = 0;
      let axisItemsCount = e.dataItem ? e.dataItem.seriesCount : 0;
      lablesPadding = Math.ceil((255 / axisItemsCount) / 3);
      lablesPadding = lablesPadding + (lablesPadding / 2);
      switch (axisItemsCount) {
        case 1:
          lablesPadding = lablesPadding - 16;
          break;
        case 2:
          lablesPadding = lablesPadding - 13;
          break;
        case 3:
          lablesPadding = lablesPadding - 13;
          break;
        case 4:
          lablesPadding = lablesPadding - 15;
          break;
        default:
          lablesPadding = 15;
          break;

      }

      rect.origin.y = rect.origin.y + lablesPadding;
      let rectLayout = new Rect(rect.origin, rect.size);
      visual = new kendo.drawing.Layout(rectLayout, {
        alignContent: "center",
        alignItems: "center",
        justifyContent: "center",
        spacing: 10,
        lineSpacing: 0
      });

      let marker = new kendo.drawing.Path({
        fill: {
          color: color
        },
        stroke: "none"
      }).moveTo(origin.x, origin.y).lineTo(bottomRight.x, origin.y).lineTo(bottomRight.x, origin.y + 20).lineTo(origin.x, origin.y + 20).close();

      visual.append(marker);
      visual.reflow();
    } else if (chartType === 'COLUMN') {
      var BAR_SIZE = 20;
      visual.transform(kendo.geometry.transform().scale(BAR_SIZE / e.rect.size.width, 1, e.rect.center()));
    } else if (chartType === 'DONUT') {
      //visual.transform(kendo.geometry.transform().scale(1.35, 1.35, [400,115]));
    }
    return visual;
  },

  createLegendItem(e) {
    let visual = e.createVisual();
    let color, labelColor, rect, layout,/* marker,*/ font, label;
    let w_data = e.series.data;

    if (this.chartType.toUpperCase() === "DONUT") {
      return visual;
    } else {
      color = e.options.markers.background;
      labelColor = e.options.labels.color;
      font = e.options.labels.font;

      if (!Ember.isEmpty(w_data[0])) {
        for (let i = 0; i < e.series.data.length; i++) {
          if (w_data[i].color) {
            color = w_data[i].color;
          }
        }
      }

      var visualPosition = visual.bbox();
      rect = new kendo.geometry.Rect(visualPosition.origin, visualPosition.size);
      layout = new kendo.drawing.Layout(rect, {
        spacing: 5,
        alignItems: "center",
      });
      var circleGeometry = new kendo.geometry.Circle([0, 0], 4);
      var circle = new kendo.drawing.Circle(circleGeometry).fill(color, 1).stroke("#cdcdcd", 0);
      label = new kendo.drawing.Text(e.series.name, '', {
        fill: {
          color: labelColor,
        },
        font: font,
      });

      layout.append(circle, label);
      layout.reflow();

      return layout;
    }

  },

  setTotalLabel(chart, toggledSeriesIndex) {
    var series = chart.options.series;
    var lastSeries = {};
    var fields = [];

    for (var i = 0; i < series.length; i++) {
      var visible = series[i].visible;

      // We're about to toggle the visibility of the clicked series
      if (i === toggledSeriesIndex) {
        visible = !visible;
      }

      if (visible) {
        fields.push("dataItem." + series[i].field);
        lastSeries = series[i];
      }

      // Clean-up existing labels
      series[i].labels = {};
    }

    lastSeries.labels = {
      visible: true,
      template: "#=" + fields.join("+") + "#"
    };
  },

  createLabelItem(e) {
    let geom = kendo.geometry;
    let Rect = geom.Rect;
    let draw = kendo.drawing;
    //let Path = draw.Path;
    let chartType = this.chartType.toUpperCase();

    let layoutConfig = (chartType === "BAR") ? {} : {
      alignContent: "center",
      alignItems: "center",
      justifyContent: "center",
      spacing: 10,
      lineSpacing: 0
    };
    let lablesPadding = 0;
    let axisItemsCount = e.dataItem.get('seriesCount') || e.dataItem.seriesCount;
    lablesPadding = Math.ceil((255 / axisItemsCount) / 3);
    lablesPadding = lablesPadding + (lablesPadding / 2);
    switch (axisItemsCount) {
      case 1:
        lablesPadding = lablesPadding - 14;
        break;
      case 2:
        lablesPadding = lablesPadding - 11;
        break;
      case 3:
        lablesPadding = lablesPadding - 12;
        break;
      case 4:
        lablesPadding = lablesPadding - 14;
        break;
      default:
        lablesPadding = 17;
        break;

    }
    if (chartType === "BAR") {
      e.rect.origin.x = e.rect.origin.x + 10;
      e.rect.origin.y = e.rect.origin.y + lablesPadding;
    }
    let rect = new Rect(e.rect.origin, e.rect.size);
    let layout = new draw.Layout(rect, layoutConfig);
    let pathA = new draw.Path().moveTo(e.rect.origin.x, e.rect.origin.y).lineTo(e.rect.origin.x + 150, e.rect.origin.y + 0).stroke("#CCCCCC", 0.5).close();
    let kendoTxt = new draw.Text(this.trimText(e.text, 15), '', e.options).fill(e.options.color);

    let color = '#00eedd';
    let racColor = e.dataItem.get('ragColor') ? e.dataItem.get('ragColor') : color;
      //used to draw circle along with lables
    let circleGeometry = new geom.Circle(e.rect.origin, 5);
    let circle = new draw.Circle(circleGeometry).fill(racColor, 1).stroke("none", 0);

    if (chartType === "BAR") {
      layout.append(kendoTxt, pathA);
    } else if (chartType === "COLUMN" || chartType === "LINE") {
      layout.append(circle, kendoTxt);
    } else {
      return e.createVisual();
    }

    layout.reflow();
    return layout;
  },

  trimText(txt, len) {
    if (!txt) {
      txt = 'Unknown';
    } else if (txt.length > len) {
      txt = txt.substring(0, len) + "...";
    }
    return txt.toUpperCase();
  },

  axisLabelClick(e) {
    if (this.isAxisLabelClick) {
      this.sendAction('chartClickAction', e);
    }

  },

  seriesClick(a_event) {
    var w_defaultSeriesClickAction = 'chartClickAction';
    if (this.customSeriesClickAction) {
      w_defaultSeriesClickAction = this.customSeriesClickAction;
      this[w_defaultSeriesClickAction] = w_defaultSeriesClickAction;
    }
    this.sendAction(w_defaultSeriesClickAction, a_event);
  },

  convertToJSON(data) {
    var dataJSON = [];
    if (data.constructor === Array && data.length > 0) {
      if (data[0].constructor === Object) {
        return data;
      } else {
        data.every(function(record) {
          if (Ember.isArray(record)) {
            record.every(function(eachSegment) {
              dataJSON.push(eachSegment.toJSON({
                includeId: true
              }));
            });
          } else {
            dataJSON.push(record.toJSON({
              includeId: true
            }));
          }
          return true;
        });
      }
    } else {
      data.every(function(record) {
        if (Ember.isArray(record)) {
          record.every(function(eachSegment) {
            dataJSON.push(eachSegment.toJSON({
              includeId: true
            }));
          });
        } else {
          dataJSON.push(record.toJSON({
            includeId: true
          }));
        }
        return true;
      });
    }
    return dataJSON;
  }
});
