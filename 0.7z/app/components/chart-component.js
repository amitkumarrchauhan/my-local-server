import Ember from 'ember';
import layout from '../templates/components/chart-component';

export default Ember.Component.extend({
    layout: layout,
    classNames: ['chartview'],
    showToolTip: false,
    chartInstance: null,
    chartData: [],
    chartLoading: false,
    willInsertElement () {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.$(window).resize(() => {
            if (!Ember.isEmpty(this.chartInstance)) {
                this.chartInstance.refresh();
            }
        });
        this.doDraw();
        this._super();
    },
    didInsertElement () {
        if (!Ember.isEmpty(this.chartInstance)) {
            this.chartInstance.resize();
        }
    },
    doDraw: Ember.observer('chartData', function () {
            var chartData = this.get('chartData');
            if (chartData && this.$('.chartview')) {
                this.chartInstance = this.$('.chartview').data("kendoChart");
                this.get('chartConfig').dataSource = {data: this.convertToJSON(chartData)};
                this.prepareDataSourceConfig (this.get('chartConfig'), this.get('chartDataSourceConfig'));
                this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
                if (this.get('chartDataSourceConfig') && this.get('chartDataSourceConfig').legendColorFlag && this.get('chartConfig').dataSource.data.length > 0) {
                    this.chartInstance.options.series.forEach(function (item) {
                        let itemField = item.field;
                        let filterArray = item.data.filter(function (item) {
                            return item[itemField] > 0;
                        });
                        if (filterArray.length > 0) {
                            item.color = item.data[0].valueColor;
                        }else {
                            item.visibleInLegend = false;
                        }
                    }.bind(this));
                }
                this.chartInstance.redraw();
            }else if (chartData) {
                this.get('chartConfig').dataSource = {data: this.convertToJSON(chartData)};
                this.prepareDataSourceConfig (this.get('chartConfig'), this.get('chartDataSourceConfig'));
            }
            return true;
        }
    ),
    prepareDataSourceConfig (chartConfig, chartDataConfig) {
        if (!Ember.isEmpty(chartDataConfig)) {
            if (chartDataConfig.isGrouping && !Ember.isEmpty(chartDataConfig.groupField)) {
                chartConfig.dataSource.group = {field: chartDataConfig.groupField, dir: Ember.isEmpty(chartDataConfig.groupOrderBy) ? 'asc' : 'desc'};
            }
            if (!Ember.isEmpty(chartDataConfig.schema)) {
                chartConfig.dataSource.schema = chartDataConfig.schema;
            }
            if (!Ember.isEmpty(chartDataConfig.sort)) {
                chartConfig.dataSource.sort = chartDataConfig.sort;
            }
        }
    },
    convertToJSON (data) {
        var dataJSON = [];
        Ember.assert('Bar Chart datasource is expected to be Ember Array', (Ember.isArray(data)));
        if (data.constructor === Array && data.length > 0) {
            if (data[0].constructor === Object) {
                return data;
            }else {
                data.every(function (record) {
                    if (Ember.isArray(record)) {
                        record.every(function (eachSegment) {
                            dataJSON.push(eachSegment.toJSON({includeId: true}));
                        });
                    }else {
                        dataJSON.push(record.toJSON({includeId: true}));
                    }
                    return true;
                });
            }
        }else {
            data.every(function (record) {
                if (Ember.isArray(record)) {
                    record.every(function (eachSegment) {
                        dataJSON.push(eachSegment.toJSON({includeId: true}));
                    });
                }else {
                    dataJSON.push(record.toJSON({includeId: true}));
                }
                return true;
            });
        }
        return dataJSON;
    },
    willDestroyElement () {
        this._super.apply(this, arguments);
        let chartInstance = this.$('.chartview').data("kendoChart");
        if (chartInstance) {
            chartInstance.destroy();
            this.$(window).off('resize');
        }
    }
});
