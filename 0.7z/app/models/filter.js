import Model from 'ember-data/model';
import { hasMany } from 'ember-data/relationships';

export default Model.extend({
  durationFilter: hasMany('durationFilter', {async: false}),
  regularFilter: hasMany('baseModel', {async: false}),
});
