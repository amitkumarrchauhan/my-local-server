import DS from 'ember-data';

export default DS.Model.extend({
  chartConfig: DS.belongsTo('chartConfig'),
  chartData: DS.belongsTo('chartData'),
  filter: DS.belongsTo('filter')
});
