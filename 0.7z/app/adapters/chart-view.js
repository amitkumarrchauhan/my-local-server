import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let chartId = '';
    let contextPath = '';
    let viewType = '';
    if (query.hasOwnProperty('chartId')) {
      chartId = query.chartId;
    }
    if (chartId.indexOf('DetailView') !== -1) {
      viewType = chartId.split('_')[0];
      viewType = viewType.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();
      contextPath = viewType + '/detailview';
    } else {
      viewType = chartId.substring(0, 2);
      chartId = chartId.substring(3, chartId.length);
      chartId = chartId.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();
      viewType = (viewType === 'LM') ? 'linemanager' : 'rolebased';
      contextPath = viewType + '/' + chartId;
    }
    return this._buildURL(contextPath);
  }
});
