import CoreApplicationAdapter from 'supdash-ui-core/adapters/application';

/**
* Purpose: This is parent class of all adapters which extends core: application adapter and is used
* calling web services if request is made via store.
*/
export default CoreApplicationAdapter.extend({
    namespace: 'cxf/sd',

    pathForType(a_type) {
        return a_type;
    }
});
