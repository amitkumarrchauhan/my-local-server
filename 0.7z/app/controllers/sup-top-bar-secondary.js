import Ember from 'ember';

export default Ember.Controller.extend({
  coreDataService: Ember.inject.service(),
  routing: Ember.inject.service('-routing'),
  routesMap: {
    generalMIS: 'home.general',
    exceptionMIS: 'home.exception'
  },
  actions: {
    changeView(selectedView) {
      console.log(selectedView);
      this.setSelectedContext(selectedView);
    },

    changeDashboardType(selectedDashboardType) {
      this.get('routing').transitionTo(this.routesMap[selectedDashboardType]);
    }
  },

  init () {

    this.store.queryRecord('topBarSecondary', {}).then((topBarSecondary) => {
      this.contextItems = topBarSecondary.get('contextItems');

      this.setProperties({
        topBarSecondary: topBarSecondary,
        selectedContext: topBarSecondary.get('selectedContext'),
        selectedContextIcon: topBarSecondary.get('selectedContextIcon'),
        dashboardTypes: this.getDasboardTabs(topBarSecondary),
        selectedDashboardType: topBarSecondary.get('selectedDashboardType')
      });
    });
  },

  getDasboardTabs(topBarSecondary) {
    let dashboardTypes = topBarSecondary.get('dashboardTypes').toArray();
    let dashboardTabs = [];

    for (let i = 0, len = dashboardTypes.length; i < len; i++) {
      let dashboardType = dashboardTypes[i];

      dashboardTabs[i] = dashboardType.toJSON();
      dashboardTabs[i]['id'] = dashboardType.get('id');
    }

    return dashboardTabs;
  },


  setSelectedContext(selectedView) {
    let contextItems = this.contextItems.toArray();

    for (let i = 0, len = contextItems.length; i < len; i++) {
      let contextItem = contextItems[i];

      if (contextItem.get('id') === selectedView) {
        this.set('selectedContext', contextItem.get('text'));
        this.set('selectedContextIcon', contextItem.get('iconClass'));

        return;
      }
    }
  }
});
