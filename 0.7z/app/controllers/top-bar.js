import Ember from 'ember';
import Base from 'supdash-ui-base/controllers/top-bar';

export default Base.extend({
  routing: Ember.inject.service('-routing'),
  coreTransition: Ember.inject.service(),

  init() {
    this._super();
  },

  actions: {
    toggleView(className) {
      if (className === 'mdi-arrow-left') {
        this.get('routing').transitionTo(this.get('coreTransition').getPreviousRoute());
      }
    }
  }
});
