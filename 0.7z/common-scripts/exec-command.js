require('shelljs/global');
var http = require('http');
var fs = require('fs');

var execCmd = function(cmd) {
  console.log('*** Executing : ' + cmd + ' ***');

  if(exec(cmd).code != 0) {
    echo("Command `" + cmd + "` failed. Please check the logs.");
    exit(1);
  }
}

var sedFile = function(regex, value, fileName) {
  if(fs.existsSync(fileName)) {
    sed('-i', regex, value, fileName);
  }
}

var download = function(url, destDir, destFile, cb) {
  var filePath = destDir + '/' + destFile;
  mkdir('-p', destDir);
  rm('-f', filePath);

  var file = fs.createWriteStream(filePath);
  console.log('Downloading ' + url + '...');
  var request = http.get(url, function(response) {
    response.pipe(file);
    file.on('finish', function() {
      file.close(cb);
    });
  });
}

var repoBaseUrl = function() {
  var env = getCurrentEnv();
  if(env == 'scb') {
    return 'http://192.168.3.5:7990/users/nileshs/repos/fm-tooling/browse';
  } else {
    return 'http://192.168.3.5:7990/users/nileshs/repos/fm-tooling/browse';
  }
}

var getConfig = function() {
  return require('../tmp/' + getCurrentEnv() + '.json');
}

var getCurrentEnv = function() {
  var env = process.env.env;
  return env ? env : 'optimum';
}

module.exports = repoBaseUrl;
global['repoBaseUrl'] = repoBaseUrl;

module.exports = getConfig;
global['getConfig'] = getConfig;

module.exports = execCmd;
global['execCmd'] = execCmd;

module.exports = download;
global['download'] = download;

module.exports = sedFile;
global['sedFile'] = sedFile;

module.exports = getCurrentEnv;
global['getCurrentEnv'] = getCurrentEnv;
