var fs = require('fs');
require('shelljs/global');

var fileName = process.argv[2];
var message = fs.readFileSync(fileName, "utf8").trim();

var regEx = new RegExp(/^\[.+\]/);

if(!regEx.test(message)) {
  console.log("  Error: Commit message not in proper format")
  console.log("  ");
  console.log("  Example valid message : ");
  console.log("  [Dev Name] Fixed the ui styling for user textbox");
  process.exit(1);
}
