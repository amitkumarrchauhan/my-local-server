require('shelljs/global');
require('../../common-scripts/exec-command');

execCmd('node build-scripts/test.js');
