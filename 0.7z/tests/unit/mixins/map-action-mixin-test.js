import Ember from 'ember';
import MapActionMixinMixin from 'supdash-ui-app/mixins/map-action-mixin';
import { module, test } from 'qunit';

module('Unit | Mixin | map action mixin');

// Replace this with your real tests.
test('it works', function(assert) {
  let MapActionMixinObject = Ember.Object.extend(MapActionMixinMixin);
  let subject = MapActionMixinObject.create();
  assert.ok(subject);
});
