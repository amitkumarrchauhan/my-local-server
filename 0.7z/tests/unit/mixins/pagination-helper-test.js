import Ember from 'ember';
import PaginationHelperMixin from 'supdash-ui-app/mixins/pagination-helper';
import { module, test } from 'qunit';

module('Unit | Mixin | pagination helper');

// Replace this with your real tests.
test('it works', function(assert) {
  let PaginationHelperObject = Ember.Object.extend(PaginationHelperMixin);
  let subject = PaginationHelperObject.create();
  assert.ok(subject);
});
