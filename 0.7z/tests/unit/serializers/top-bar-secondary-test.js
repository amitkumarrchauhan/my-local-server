import { moduleForModel, test } from 'ember-qunit';

moduleForModel('top-bar-secondary', 'Unit | Serializer | top bar secondary', {
  // Specify the other units that are required for this test.
  needs: ['serializer:top-bar-secondary']
});

// Replace this with your real tests.
test('it serializes records', function(assert) {
  let record = this.subject();

  let serializedRecord = record.serialize();

  assert.ok(serializedRecord);
});
