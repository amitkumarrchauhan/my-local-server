import { moduleFor, test } from 'ember-qunit';

moduleFor('controller:sup-top-bar-secondary', 'Unit | Controller | sup top bar secondary', {
  // Specify the other units that are required for this test.
  // needs: ['controller:foo']
});

// Replace this with your real tests.
test('it exists', function(assert) {
  let controller = this.subject();
  assert.ok(controller);
});
