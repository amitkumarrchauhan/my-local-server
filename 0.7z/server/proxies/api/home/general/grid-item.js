var requireModule = require;

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/griditem', function(request, response) {
    var pageJSON;
    var gridItemId = request.query.gridItemId;
    var _dataURL = '../../../_data/home/general/' + gridItemId;
    console.log('********' + gridItemId + '********');

    pageJSON = requireModule(_dataURL + '.json');
    pageJSON.gridItem.gridData = requireModule(_dataURL +'-data.json').gridData;

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
