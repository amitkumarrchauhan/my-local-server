module.exports = function(app) {
  var express = require('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/getdashboardlist', function(req, res) {
    var pageJSON = "{}";
    pageJSON = require('../../_data/home/exception/dashboard-list.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 100);
  });

  app.use(app.contextPath + '/linemanager', mockServerRouter);
};
