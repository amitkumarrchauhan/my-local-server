module.exports = function(app) {
  var express = require('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/detailview', function(req, res) {
    var pageJSON = "{}";
    pageJSON = require('../../_data/home/exception/column.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 0);
  });

  app.use(app.contextPath + '/:linemanager', mockServerRouter);
};
