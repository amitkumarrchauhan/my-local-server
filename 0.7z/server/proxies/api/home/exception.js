module.exports = function (app) {
    var express = require('express'),
    mockServerRouter = express.Router();

    mockServerRouter.get('/viewbydashbaord', function (req, res) {
        var pageJSON = "{}";
        pageJSON = require('../../_data/home/exception/donut.json');
        res.header("Access-Control-Allow-Origin", "*");
        setTimeout(function() {
            res.json(pageJSON);
        }, 1000);
    });

      mockServerRouter.get('/viewbyemployee', function (req, res) {
        var pageJSON = "{}";
        var jsonRes = req.query.chartType;
        pageJSON = require('../../_data/home/exception/bar.json');
        res.header("Access-Control-Allow-Origin", "*");
        setTimeout(function() {
            res.json(pageJSON);
        }, 0);
    });

        mockServerRouter.get('/viewbysummary', function (req, res) {
        var pageJSON = "{}";
        var jsonRes = req.query.chartType;
        pageJSON = require('../../_data/home/exception/line.json');
        res.header("Access-Control-Allow-Origin", "*");
        setTimeout(function() {
            res.json(pageJSON);
        }, 0);
    });

    app.use(app.contextPath + '/linemanager', mockServerRouter);
};
