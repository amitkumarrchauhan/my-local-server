// To use it create some files under `mocks/`
// e.g. `server/mocks/ember-hamsters.js`
//
// module.exports = function(app) {
//   app.get('/ember-hamsters', function(req, res) {
//     res.send('hello');
//   });
// };

/* MOVED ALL WARNINGS ON TOP AT ONE PLACE*/
var requireModule = require;
var dirName = __dirname;

module.exports = function(app) {
  var globSync = requireModule('glob').sync;
  var mocks = globSync('./mocks/**/*.js', {
    cwd: dirName
  }).map(requireModule);
  var proxies = globSync('./proxies/**/*.js', {
    cwd: dirName
  }).map(requireModule);

  // Log proxy requests
  var morgan = requireModule('morgan');
  app.use(morgan('dev'));

  app.contextPath = '/cxf/sd';

  mocks.forEach(function(route) {
    route(app);
  });

  proxies.forEach(function(route) {
    route(app);
  });
};
