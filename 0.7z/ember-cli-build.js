/* global require, module */
var EmberApp = require('ember-cli/lib/broccoli/ember-app'), appConfig, fs = require('fs');
var updateVersion = function (appConfig) {
    if (appConfig && appConfig.fingerprint && process.env.version) {
        appConfig.fingerprint['customHash'] = process.env.version;
    }
};

module.exports = function (defaults) {
    appConfig = JSON.parse(fs.readFileSync('./build-config.json'))[EmberApp.env()];

    updateVersion(appConfig);

    var app = new EmberApp(defaults, appConfig || {});

    /*
    app.import(app.bowerDirectory + '/es5-shim/es5-shim.js');
    app.import(app.bowerDirectory + '/jquery-mockjax/jquery.mockjax.js', { type: 'test' });
    */
    app.import(app.bowerDirectory + '/materialize/dist/css/materialize.min.css');

    return app.toTree();
};
