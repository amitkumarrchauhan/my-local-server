require('./common-scripts/exec-command');
var nodeProcess = process;
var execute = execCmd;

function setReleaseNo() {
  function deriveReleaseNo() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var todaysDate = date.getDate();

    month = (month + '').length !== 2 ? '0' + month : month;
    todaysDate = (todaysDate + '').length !== 2 ? '0' + todaysDate : todaysDate;

    return (year + '' + month + '' + todaysDate);
  }

  var version = nodeProcess.env.version;

  if (!version) {
    nodeProcess.env.version = '1.0.0.' + deriveReleaseNo();
  }

  return nodeProcess.env.version;
}

(function() {
  var autoRefresh = nodeProcess.env.autoRefresh;

  execute('rm -rf tmp');

  if (nodeProcess.env.updateAddon) {
    execute('node setup-project.js');
  }

  console.log('*** Release No: ' + setReleaseNo() + ' ***');

  execute('ember s' + (autoRefresh === true || autoRefresh === 'true' ? ' -lrp 9000' : ''));
}());
