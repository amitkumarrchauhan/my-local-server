require('./common-scripts/exec-command');

var addons = process.env.addon;
var updateAddon = process.env.updateAddon;
var execute = execCmd;
var ADDON_REPOS = {
  core: '../ADDONS/supdash-ui-core',
  base: '../ADDONS/supdash-ui-base',
  comp: '../ADDONS/supdash-ui-components',
  theme: '../ADDONS/supdash-ui-theme',
  mat: '../ADDONS/ember-cli-materialize'
};

addons = addons ? addons.split(',') : ['all'];

if (updateAddon === 'true' || updateAddon === true) {
  console.log('addons to be installed are: '+ addons);
  if (addons[0] === 'all' || !addons) {
    console.log('installing addons');
    execute('ember install ' + ADDON_REPOS.core);
    execute('ember install ' + ADDON_REPOS.base);
    execute('ember install ' + ADDON_REPOS.comp);
    //execute('ember install ' + ADDON_REPOS.theme);
  } else {
    for (var i = 0; i < addons.length; i++) {
      var addon = addons[i];

      if (ADDON_REPOS[addon]) {
        execute('ember install ' + ADDON_REPOS[addon]);
      } else {
        console.log('*** '+ addon +' does not exist !!! ***');
      }
    }
  }
} else {
  console.log('not installing addons');
}
