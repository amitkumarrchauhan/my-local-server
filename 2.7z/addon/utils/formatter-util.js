import Ember from 'ember';

export default Ember.Object.create ({
    formatNumericValue (value) {
        if (value) {
            return numeral(value).format('0,0.0');
        }

        return 0;
    }
});
