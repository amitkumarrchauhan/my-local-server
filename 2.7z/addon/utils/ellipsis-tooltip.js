import Ember from "ember";
export default Ember.Object.create ({
    bindTooltip(e) {
        var target = e.target;
        if (this.isEllipsisActive(target) && Ember.isEmpty(target.title)) {
            target.title = target.outerText;
        }
    },
    isEllipsisActive(e) {
        return e.clientWidth < e.scrollWidth;
    }
});
