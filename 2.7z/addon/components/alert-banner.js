import Ember from 'ember';
import layout from '../templates/components/alert-banner';

export default Ember.Component.extend({
    tagName: 'div',
    layout: layout,
    classNames: ['alert'],
    classNameBindings: ['isSuccess:alert-success', 'isInfo:alert-info', 'isWarning:alert-warning', 'isError:alert-danger'],
    type: '',
    isSuccess: Ember.computed('type', {
        get() {
            if (!Ember.isEmpty(this.get('type')) && this.get('type').toLowerCase() === 'success') {
                return true;
            }
            return false;
        }
    }),
    isInfo: Ember.computed('type', {
        get() {
            if (!Ember.isEmpty(this.get('type')) && this.get('type').toLowerCase() === 'info') {
                return true;
            }
            return false;
        }
    }),
    isWarning: Ember.computed('type', {
        get() {
            if (!Ember.isEmpty(this.get('type')) && this.get('type').toLowerCase() === 'warning') {
                return true;
            }
            return false;
        }
    }),
    isError: Ember.computed('type', {
        get() {
            if (!Ember.isEmpty(this.get('type')) && this.get('type').toLowerCase() === 'error') {
                return true;
            }
            return false;
        }
    })
});
