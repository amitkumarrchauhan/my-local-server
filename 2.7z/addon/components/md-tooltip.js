import Ember from 'ember';
import layout from '../templates/components/md-tooltip';
import cs from 'supdash-ui-components/mixins/component-support';
export default Ember.Component.extend(cs, {
    layout: layout,
    width: null,// If no tagName componet will have span as tag name
    classNames: ['flyout'],
    target: 'span', //by default it is span user can change if needed
    didInsertElement: function () {
        var input = this.$('.flyout'),
        instance = this.$(input),
        options = {};
        this.setKendoOption(options, 'filter', 'target');
        this.setKendoOption(options, 'content', 'content');
        this.setKendoOption(options, 'position', 'position');
        this.setKendoOption(options, 'width', 'width');
        instance.kendoTooltip(options);
    }
});
