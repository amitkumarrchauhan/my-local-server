import Ember from 'ember';
import layout from '../templates/components/default-login-box';

export default Ember.Component.extend({
    layout: layout,
    actions: {
        authenticate: function (cb) {
            this.sendAction('action', cb);
        }
    }
});
