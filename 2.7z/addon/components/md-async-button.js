import Ember from 'ember';
import AsyncButton from 'ember-cli-async-button/components/async-button';

export default AsyncButton.extend({
    // Using "_attributeBindings" because we don't want to override AsyncButton config
    _attributeBindings: [
        'disabled',
        'action',
        'data-dismiss'
    ],
    /**
     * This will help to provide DOM element, where the widget has to render.
     *
     * @property {string} tagName
     * @default  'span'
     */
    init: function () {
        // Pushing into attributeBindings and classNameBindings because we don't want to override AsyncButton config
        this.set('attributeBindings', this.get('attributeBindings').concat(this.get('_attributeBindings')));
        this.set('classNameBindings', this.get('classNameBindings').concat(['getClasses']));
        this._super();
    },

    /**
     * The Property size is used to accept size of button from user.
     * Acceptable sizes are : lg/sm/xs/block
     *
     * @property {string} size
     * @default  ''
     */
    size: '',

    /**
     * The Property icon is used to accept class to be placed on button to display icon.
     *
     * @property {string} icon
     * @default  ''
     */
    icon: '',

    /**
     * The Property params not used in widget. It is a supporting property.
     * WHen user captures an action on click of button, he can pass params if needed in this property.
     *
     * @property {Object} params
     * @default  null
     */
    params: null,

    /**
     * The Property disabled is used to set the status of button as disabled and user will not be allowed to click the button.
     *
     * @property {Object} model
     * @default  null
     */
    model: null,
    tooltipMsg: '',
    willInsertElement: function () {
        // binding the tooltip on willInsertElement, if provided
        var ele = this.$();
        if (!Ember.isEmpty(ele) && this.get('tooltipMsg')) {
            ele.tooltip({
                title : this.get('tooltipMsg'),
                placement: function () {
                    var position = ele.position();
                    if (position.top < 60) {
                        return 'bottom';
                    }

                    return 'top';
                }
            });
        }
    },
    /**
     * Identify the classes based on type/size/icon.
     *
     * @function getClasses
     * @returns  {string}
     */
    getClasses: Ember.computed('size', 'type', 'icon', 'text', {
        get() {
            var btnClasses = '', sizeClass = '', typeClass = '', size = this.get('size'), type = this.get('type');

            if (!Ember.isEmpty(this.get('icon')) && !Ember.isEmpty(this.get('text'))) {
                btnClasses = btnClasses + 'btn wb-btn-default ' + this.get('icon');
                return btnClasses;
            } else if (!Ember.isEmpty(this.get('icon'))) {
                btnClasses = btnClasses + 'btn icon-button ' + this.get('icon');
                return btnClasses;
            }

            btnClasses = btnClasses + 'btn';
            if (!Ember.isEmpty(type)) {
                typeClass = ('wb-btn-' + type);
                btnClasses = btnClasses + ' ' + typeClass;
            }
            if (!Ember.isEmpty(size)) {
                sizeClass = ('btn-' + size);
                btnClasses = btnClasses + ' ' + sizeClass;
            }

            if (btnClasses === 'btn') {
                btnClasses = btnClasses + ' wb-btn-default';
            }
            return btnClasses;
        }
    }),

    /**
     * Capture the click event and fires the action for user by the name specified by him in action attribute.
     *
     * @function click
     * @returns  {void}action
     */
    click(e) {
        if (this.get('async') === true) {
            this._super.apply(this, arguments);
        } else {
            this.sendAction('action', this.get('params'), this.get('model'), e);
        }
    }
});
