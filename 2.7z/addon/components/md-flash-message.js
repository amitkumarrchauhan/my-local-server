import Ember from 'ember';
import layout from '../templates/components/md-flash-message';
import FlashMessage from 'ember-cli-flash/components/flash-message';

export default FlashMessage.extend({
    layout: layout,
    message: null,
    classNameBindings: ['isHidden:hide'],
    sticky: false,
    isHidden: Ember.computed('hasMessages', function () {
        return !this.get('hasMessages');
    }),
    hasMessages: Ember.computed('mdFlashMessages.queue.length', {
        get: function () {
            return (this.get('mdFlashMessages.queue.length') > 0);
        }
    }),
    actions: {
        closeMessage() {
            var clearedMessages = this.mdFlashMessages.get('queue');
            clearedMessages.forEach(function (message) {
                message.destroyMessage();
            });
            this.sendAction('flash-message-closed');
        }
    }
});
