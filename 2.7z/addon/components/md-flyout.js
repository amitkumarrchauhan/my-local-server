import Ember from 'ember';
import layout from '../templates/components/md-flyout';

export default Ember.Component.extend({
    layout: layout,
    classNames : ['wb-flyout'],
    loadingInProgress: false,
    buttons: Ember.computed('config.buttons.[]', {
        get() {
            return this.get('config.buttons');
        }
    }),
    init: function () {
        this._super();
        if (this.flyoutManager != null) {
            this.flyoutManager.set('activeFlyout', this);
        }
    },
    actions: {
        headerBtnClicked() {
            this.set('attrs.' + arguments[1].action, arguments[1].action);
            this.sendAction(arguments[1].action);
        },
        close() {
            //Do not close flyout , if loading is in progress
            if (this.get('loadingInProgress') !== true) {
                this.sendAction('close');
            }
        },
        showLoadingIndicator() {
            this.set('loadingInProgress', true);
        },
        hideLoadingIndicator() {
            this.set('loadingInProgress', false);
        }
    }
});
