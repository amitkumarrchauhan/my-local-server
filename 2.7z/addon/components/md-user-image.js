import Ember from 'ember';

export default Ember.Component.extend({
  tagName: 'img',
  attributeBindings: ['image-src', 'alt', 'src'],
  checkForBrokenImage: true,
  alt: "User Image",
  src: Ember.computed('image-src', {
    get() {
      var defaultImageUrl = this.get('defaultImageUrl'),
        imageSrc = this.get('image-src');
      if (!imageSrc) {
        return defaultImageUrl;
      } else {
        Ember.run.schedule('afterRender', function() {
          this.$().off().on('error', function() {
            //After handling the error, Remove all event handler
            Ember.$(this).off().attr("src", defaultImageUrl);
          });
        }.bind(this));
        return imageSrc;
      }
      this._super();
    }
  }),
  /* Return defaults user image, along with version number */
  defaultImageUrl: Ember.computed({
    get() {
      var userImage = "supdash-ui-base/images/user-photo";

      return userImage + ".jpg";
    }
  })
});
