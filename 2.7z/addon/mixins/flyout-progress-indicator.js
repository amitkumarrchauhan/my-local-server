import Ember from 'ember';
const { getOwner } = Ember;

export default Ember.Mixin.create({
    getFlyoutInstance () {
        return this.childViews[0];
    },
    showProgressIndicator () {
        this.getFlyoutInstance().send('showLoadingIndicator');
    },
    hideProgressIndicator (error) {
        this.getFlyoutInstance().send('hideLoadingIndicator');
        if (error) {
            this.flashErrorMessage(error);
        }
    },
    flashErrorMessage (error) {
        /** Need to refactor this **/
        var errorMsg, defaultErrorMessage = "Unknown error occured", errorObject;
        if (error) {
            if (typeof error === "string") {
                errorMsg = error;
            } else if (error.responseText) {
                try {
                    errorObject = JSON.parse(error.responseText);
                    if (errorObject.errors) {
                        errorMsg = errorObject.errors[0].code + " - " + errorObject.errors[0].detail;
                    } else if (errorObject.message) {
                        errorMsg = errorObject.message;
                    }
                } catch (e) {
                    errorMsg = "Server has sent invalid error message!";
                }
            } else if (error.errors instanceof Array && error.errors.length > 0) {
                errorMsg = error.errors[0].code + " - " + error.errors[0].detail;
            }
        }
        getOwner(this).lookup('service:mdFlashMessages').success(errorMsg || defaultErrorMessage);
    }
});
