import Ember from 'ember';

export function notNull(params) {
    for (var i = 0, len = params.length ; i < len; i++) {
        if (!params[i]) {
            return false;
        }
    }
    return true;
}

export default Ember.Helper.helper(notNull);
