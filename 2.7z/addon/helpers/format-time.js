import Ember from 'ember';

export function formatTime(params) {
    var date = params[0],
    inputFormat = params[1],
    getOption = params [2],
    defaultFormat = "DD MMM YYYY",
    output = "N/A";
    if (params[0]) {
        if (!getOption) {
            if (Ember.isEmpty(inputFormat)) {
                output = moment(date).format(defaultFormat);
            } else {
                output = moment(date).format(inputFormat);
            }
        } else {
            if (getOption === "calendar") {
                output = moment(date).calendar();
            } else {
                output = moment(date).fromNow();
            }
        }
    }
    return output;
}

export default Ember.HTMLBars.makeBoundHelper(formatTime);
