import Ember from 'ember';

export function lowerCase(params/*, hash*/) {
    var str = params[0];
    if (str != null) {
        return str.toLowerCase();
    }
    return str;
}

export default Ember.Helper.helper(lowerCase);
