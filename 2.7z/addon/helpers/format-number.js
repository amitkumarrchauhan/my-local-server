import Ember from 'ember';

export function formatNumber(params) {
    Ember.assert("No parameter passed to format-number helper", params.length > 0);
    return accounting.formatNumber(params[0]);
}

export default Ember.Helper.helper(formatNumber);
