import flashMessagesService from 'ember-cli-flash/services/flash-messages';
import config from '../config/environment';

export function initialize(application) {
    const { mdFlashMessageDefaults } = config;
    const { injectionFactories } = mdFlashMessageDefaults;

    application.register('config:md-flash-messages', mdFlashMessageDefaults, { instantiate: false });
    application.register('service:md-flash-messages', flashMessagesService, { singleton: true });

    //DO NOT rename the 'flashMessageDefaults'- flash-message-service expects this name
    application.inject('service:md-flash-messages', 'flashMessageDefaults', 'config:md-flash-messages');

    injectionFactories.forEach((factory) => {
        application.inject(factory, 'mdFlashMessages', 'service:md-flash-messages');
    });

    //TODO - Find a way to unregister 'service:flash-messages', it not needed
    //_container.unregister('service:flash-messages');
}

export default {
    name: 'md-flash-message',
    after: 'flash-messages',
    initialize: initialize
};
