import ProgressIndicator from 'supdash-ui-components/mixins/flyout-progress-indicator';

export default ProgressIndicator;
