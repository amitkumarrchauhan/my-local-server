export { default } from 'supdash-ui-components/utils/ellipsis-tooltip';
