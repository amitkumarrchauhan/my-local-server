export { default } from 'supdash-ui-components/components/md-flyout';
