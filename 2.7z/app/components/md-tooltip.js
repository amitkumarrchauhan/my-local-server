import wbTooltip from 'supdash-ui-components/components/md-tooltip';

export default wbTooltip;
