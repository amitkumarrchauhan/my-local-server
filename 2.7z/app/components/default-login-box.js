import defaultLoginBox from 'supdash-ui-components/components/default-login-box';

export default defaultLoginBox;
