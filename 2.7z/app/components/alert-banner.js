export { default } from 'supdash-ui-components/components/alert-banner';
