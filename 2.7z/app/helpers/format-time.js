export { default, wbFormatTime } from 'supdash-ui-components/helpers/format-time';
